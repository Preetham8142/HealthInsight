import fs from 'fs';
import path from 'path';

export interface CleaningOptions {
  missing_strategy: 'mean' | 'median' | 'drop' | 'mode';
  remove_duplicates: boolean;
  handle_outliers: boolean;
  scaling: 'none' | 'min-max' | 'standard';
}

export interface CleaningReport {
  before: {
    rows: number;
    columns: number;
    missing_values: number;
    duplicates: number;
  };
  after: {
    rows: number;
    columns: number;
    missing_values: number;
    duplicates: number;
  };
  outliers_handled: number;
  cleaned_file_path: string;
  cleaned_filename: string;
  preview: Record<string, any>[];
}

export function parseCSV(content: string): { headers: string[]; rows: Record<string, string>[] } {
  const lines = content.split(/\r?\n/).filter(line => line.trim().length > 0);
  if (lines.length === 0) return { headers: [], rows: [] };

  function splitLine(line: string): string[] {
    const values: string[] = [];
    let current = '';
    let inQuotes = false;
    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      if (char === '"' || char === "'") {
        inQuotes = !inQuotes;
      } else if (char === ',' && !inQuotes) {
        values.push(current.trim().replace(/^["']|["']$/g, ''));
        current = '';
      } else {
        current += char;
      }
    }
    values.push(current.trim().replace(/^["']|["']$/g, ''));
    return values;
  }

  const headers = splitLine(lines[0]);
  const rows: Record<string, string>[] = [];

  for (let i = 1; i < lines.length; i++) {
    const vals = splitLine(lines[i]);
    const row: Record<string, string> = {};
    headers.forEach((h, idx) => {
      row[h] = vals[idx] !== undefined ? vals[idx] : '';
    });
    rows.push(row);
  }

  return { headers, rows };
}

export function cleanDatasetPipeline(
  rawCSVContent: string,
  originalFilename: string,
  options: CleaningOptions = {
    missing_strategy: 'median',
    remove_duplicates: true,
    handle_outliers: true,
    scaling: 'none'
  }
): CleaningReport {
  const { headers, rows } = parseCSV(rawCSVContent);

  const initialRows = rows.length;
  const initialCols = headers.length;

  // Detect missing values initially
  let initialMissing = 0;
  for (const r of rows) {
    for (const h of headers) {
      const val = r[h];
      if (val === undefined || val === null || val === '' || val.toLowerCase() === 'na' || val.toLowerCase() === 'nan' || val.toLowerCase() === 'null') {
        initialMissing++;
      }
    }
  }

  // Duplicate detection initially
  const seenRowStrings = new Set<string>();
  let initialDuplicates = 0;
  for (const r of rows) {
    const serialized = headers.map(h => r[h]).join('|');
    if (seenRowStrings.has(serialized)) {
      initialDuplicates++;
    } else {
      seenRowStrings.add(serialized);
    }
  }

  // Step 1: Remove duplicates if selected
  let processedRows: Record<string, any>[] = [];
  if (options.remove_duplicates) {
    const uniqueMap = new Set<string>();
    for (const r of rows) {
      const key = headers.map(h => r[h]).join('|');
      if (!uniqueMap.has(key)) {
        uniqueMap.add(key);
        processedRows.push({ ...r });
      }
    }
  } else {
    processedRows = rows.map(r => ({ ...r }));
  }

  // Identify numeric vs categorical columns
  const numericCols: string[] = [];
  const categoricalCols: string[] = [];

  for (const h of headers) {
    let numericCount = 0;
    let validCount = 0;
    for (const r of processedRows) {
      const val = r[h];
      if (val !== undefined && val !== '' && val !== null) {
        validCount++;
        if (!isNaN(Number(val))) {
          numericCount++;
        }
      }
    }
    if (validCount > 0 && numericCount / validCount > 0.8) {
      numericCols.push(h);
    } else {
      categoricalCols.push(h);
    }
  }

  // Step 2: Handle missing values
  if (options.missing_strategy === 'drop') {
    processedRows = processedRows.filter(r => {
      for (const h of headers) {
        const val = r[h];
        if (val === undefined || val === null || val === '' || String(val).toLowerCase() === 'nan' || String(val).toLowerCase() === 'null') {
          return false;
        }
      }
      return true;
    });
  } else {
    // Impute numerical columns with mean or median
    for (const col of numericCols) {
      const nums = processedRows
        .map(r => Number(r[col]))
        .filter(n => !isNaN(n))
        .sort((a, b) => a - b);

      if (nums.length === 0) continue;
      const sum = nums.reduce((a, b) => a + b, 0);
      const mean = sum / nums.length;
      const mid = Math.floor(nums.length / 2);
      const median = nums.length % 2 === 0 ? (nums[mid - 1] + nums[mid]) / 2 : nums[mid];
      const replacement = options.missing_strategy === 'mean' ? Number(mean.toFixed(2)) : Number(median.toFixed(2));

      for (const r of processedRows) {
        const val = r[col];
        if (val === undefined || val === null || val === '' || isNaN(Number(val))) {
          r[col] = replacement;
        } else {
          r[col] = Number(val);
        }
      }
    }

    // Impute categorical columns with mode
    for (const col of categoricalCols) {
      const freq = new Map<string, number>();
      for (const r of processedRows) {
        const val = String(r[col] || '').trim();
        if (val && val.toLowerCase() !== 'nan' && val.toLowerCase() !== 'null') {
          freq.set(val, (freq.get(val) || 0) + 1);
        }
      }
      let mode = 'Unknown';
      let maxCount = 0;
      for (const [v, c] of freq.entries()) {
        if (c > maxCount) {
          maxCount = c;
          mode = v;
        }
      }

      for (const r of processedRows) {
        const val = String(r[col] || '').trim();
        if (!val || val.toLowerCase() === 'nan' || val.toLowerCase() === 'null') {
          r[col] = mode;
        }
      }
    }
  }

  // Step 3: Outlier handling using IQR (clip to Q1 - 1.5*IQR and Q3 + 1.5*IQR)
  let outliersHandled = 0;
  if (options.handle_outliers) {
    for (const col of numericCols) {
      const vals = processedRows
        .map(r => Number(r[col]))
        .filter(n => !isNaN(n))
        .sort((a, b) => a - b);

      if (vals.length < 8) continue;
      const q1 = vals[Math.floor(vals.length * 0.25)];
      const q3 = vals[Math.floor(vals.length * 0.75)];
      const iqr = q3 - q1;
      const lowerBound = q1 - 1.5 * iqr;
      const upperBound = q3 + 1.5 * iqr;

      for (const r of processedRows) {
        const num = Number(r[col]);
        if (num < lowerBound) {
          r[col] = Number(lowerBound.toFixed(2));
          outliersHandled++;
        } else if (num > upperBound) {
          r[col] = Number(upperBound.toFixed(2));
          outliersHandled++;
        }
      }
    }
  }

  // Step 4: Scaling if requested
  if (options.scaling === 'min-max') {
    for (const col of numericCols) {
      const vals = processedRows.map(r => Number(r[col]));
      const min = Math.min(...vals);
      const max = Math.max(...vals);
      const range = max - min || 1;
      for (const r of processedRows) {
        r[col] = Number(((Number(r[col]) - min) / range).toFixed(4));
      }
    }
  }

  // Save cleaned dataset to disk
  const cleanedHeaders = headers;
  const cleanedCSVLines = [
    cleanedHeaders.join(','),
    ...processedRows.map(r => cleanedHeaders.map(h => {
      const v = r[h];
      return typeof v === 'string' && (v.includes(',') || v.includes('"')) ? `"${v}"` : v;
    }).join(','))
  ];

  const cleanedFilename = `cleaned_${Date.now()}_${path.basename(originalFilename)}`;
  const cleanedFilePath = path.resolve(process.cwd(), 'data', cleanedFilename);
  fs.writeFileSync(cleanedFilePath, cleanedCSVLines.join('\n'), 'utf-8');

  return {
    before: {
      rows: initialRows,
      columns: initialCols,
      missing_values: initialMissing,
      duplicates: initialDuplicates
    },
    after: {
      rows: processedRows.length,
      columns: cleanedHeaders.length,
      missing_values: 0,
      duplicates: 0
    },
    outliers_handled: outliersHandled,
    cleaned_file_path: cleanedFilePath,
    cleaned_filename: cleanedFilename,
    preview: processedRows.slice(0, 20)
  };
}
