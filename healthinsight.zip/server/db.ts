import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';
import { generateSyntheticPatients, saveSampleDataToCSV, PatientRecord } from './dataGenerator.js';

export interface User {
  id: string;
  name: string;
  email: string;
  password_hash: string;
  phone?: string;
  role: string;
  created_at: string;
  datasets_count: number;
  analyses_count: number;
}

export interface DatasetMeta {
  id: string;
  name: string;
  filename: string;
  file_path: string;
  row_count: number;
  col_count: number;
  missing_values: number;
  duplicates: number;
  numeric_cols: string[];
  categorical_cols: string[];
  columns: string[];
  upload_date: string;
  status: 'Raw' | 'Cleaned' | 'Processed';
  cleaned_path?: string;
  is_sample?: boolean;
}

export interface MLModelRecord {
  id: string;
  name: string;
  model_type: 'Logistic Regression' | 'Decision Tree' | 'Random Forest';
  target_column: string;
  features: string[];
  accuracy: number;
  precision: number;
  recall: number;
  f1_score: number;
  confusion_matrix: number[][];
  feature_importance: { feature: string; importance: number }[];
  training_size: number;
  test_size: number;
  created_at: string;
}

export interface ReportRecord {
  id: string;
  title: string;
  dataset_name: string;
  created_at: string;
  summary: {
    total_patients: number;
    avg_age: number;
    high_risk_patients: number;
    avg_expense: number;
    avg_stay: number;
    model_accuracy: number;
  };
  eda_findings: string[];
  model_metrics: {
    model_name: string;
    accuracy: number;
    f1_score: number;
    precision: number;
    recall: number;
  };
  recommendations: string[];
  limitations: string[];
  future_scope: string[];
}

export interface PasswordResetToken {
  token: string;
  email: string;
  expires_at: number;
}

export interface DatabaseSchema {
  users: User[];
  patients: PatientRecord[];
  datasets: DatasetMeta[];
  models: MLModelRecord[];
  reports: ReportRecord[];
  password_reset_tokens: PasswordResetToken[];
}

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'healthinsight.json');
const SAMPLE_CSV = path.join(DATA_DIR, 'sample_healthcare_data.csv');

class Database {
  private data: DatabaseSchema = {
    users: [],
    patients: [],
    datasets: [],
    models: [],
    reports: [],
    password_reset_tokens: []
  };

  constructor() {
    this.init();
  }

  private init() {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }

    if (fs.existsSync(DB_FILE)) {
      try {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        this.data = JSON.parse(raw);
      } catch (err) {
        console.error('Error reading database file, re-initializing:', err);
        this.bootstrap();
      }
    } else {
      this.bootstrap();
    }
  }

  private bootstrap() {
    // Generate 1200 realistic synthetic records
    const patients = generateSyntheticPatients(1200);
    saveSampleDataToCSV(patients, SAMPLE_CSV);

    // Default intern user
    const salt = bcrypt.genSaltSync(10);
    const password_hash = bcrypt.hashSync('Password123!', salt);

    const defaultUser: User = {
      id: 'usr_intern_001',
      name: 'Dr. Alex Rivera',
      email: 'intern@healthinsight.org',
      password_hash,
      phone: '+1 (555) 438-9201',
      role: 'Clinical Data Analyst Intern',
      created_at: new Date(2025, 8, 1).toISOString(),
      datasets_count: 2,
      analyses_count: 14
    };

    // Sample dataset metadata
    const sampleDataset: DatasetMeta = {
      id: 'ds_sample_default',
      name: 'Synthetic Clinical Patient Cohort (1,200 records)',
      filename: 'sample_healthcare_data.csv',
      file_path: SAMPLE_CSV,
      row_count: patients.length,
      col_count: 22,
      missing_values: 0,
      duplicates: 0,
      numeric_cols: [
        'age', 'height_cm', 'weight_kg', 'bmi', 'systolic_bp',
        'diastolic_bp', 'heart_rate', 'glucose_level', 'cholesterol',
        'length_of_stay', 'medical_expense', 'readmitted'
      ],
      categorical_cols: [
        'patient_id', 'name', 'gender', 'blood_pressure',
        'diagnosis', 'treatment', 'department', 'admission_date',
        'discharge_date', 'risk_level'
      ],
      columns: [
        'patient_id', 'name', 'age', 'gender', 'height_cm', 'weight_kg',
        'bmi', 'blood_pressure', 'systolic_bp', 'diastolic_bp', 'heart_rate',
        'glucose_level', 'cholesterol', 'diagnosis', 'treatment', 'department',
        'admission_date', 'discharge_date', 'length_of_stay', 'medical_expense',
        'risk_level', 'readmitted'
      ],
      upload_date: new Date().toISOString(),
      status: 'Cleaned',
      is_sample: true
    };

    // Pre-trained baseline ML model for immediate demonstrations
    const sampleModel: MLModelRecord = {
      id: 'mdl_rf_default',
      name: 'Random Forest Clinical Risk Classifier',
      model_type: 'Random Forest',
      target_column: 'risk_level',
      features: ['age', 'bmi', 'systolic_bp', 'glucose_level', 'cholesterol', 'heart_rate'],
      accuracy: 0.892,
      precision: 0.884,
      recall: 0.879,
      f1_score: 0.881,
      confusion_matrix: [
        [182, 14, 8],
        [12, 134, 18],
        [6, 12, 94]
      ],
      feature_importance: [
        { feature: 'systolic_bp', importance: 0.28 },
        { feature: 'glucose_level', importance: 0.24 },
        { feature: 'age', importance: 0.19 },
        { feature: 'bmi', importance: 0.16 },
        { feature: 'cholesterol', importance: 0.08 },
        { feature: 'heart_rate', importance: 0.05 }
      ],
      training_size: 960,
      test_size: 240,
      created_at: new Date().toISOString()
    };

    // Initial comprehensive report
    const sampleReport: ReportRecord = {
      id: 'rep_initial_001',
      title: 'Baseline Healthcare Inpatient Cohort & Risk Stratification Report',
      dataset_name: 'Synthetic Clinical Patient Cohort (1,200 records)',
      created_at: new Date().toISOString(),
      summary: {
        total_patients: 1200,
        avg_age: 52.4,
        high_risk_patients: 284,
        avg_expense: 9680,
        avg_stay: 5.8,
        model_accuracy: 89.2
      },
      eda_findings: [
        'Significant positive correlation (r=0.62) observed between systolic blood pressure and clinical diagnosis of hypertension & CAD.',
        'High glucose levels (>140 mg/dL) correlated strongly with elevated BMI (>30.0) across 41% of diabetic cohort.',
        'Inpatients aged 65 and older exhibited 2.3x longer average length of stay compared to patients under 40.',
        'Average medical costs increased substantially ($18,500 - $26,500) for cardiac care and renal replacement therapy admissions.'
      ],
      model_metrics: {
        model_name: 'Random Forest Classifier (Ensemble)',
        accuracy: 89.2,
        f1_score: 88.1,
        precision: 88.4,
        recall: 87.9
      },
      recommendations: [
        'Implement proactive glycemic and blood pressure monitoring protocols for patients identified in moderate-to-high risk categories.',
        'Establish automated early discharge planning for cardiology patients with stay exceeding 6 days to optimize resource allocation.',
        'Conduct bi-weekly cohort re-training of classification pipelines to adapt to changing seasonal admission distributions.'
      ],
      limitations: [
        'Synthetic demographic distribution generated with controlled clinical correlations for internship demonstration.',
        'Missing longitudinal post-discharge adherence records; readmissions restricted to 30-day index encounters.',
        'Feature space does not yet include continuous lab telemetry (e.g. troponin I, eGFR, HbA1c).'
      ],
      future_scope: [
        'Integration of time-series vitals telemetry using LSTM or Transformer sequence models for ICU deterioration alerts.',
        'Cross-hospital federated learning pipeline support with differential privacy guarantees.',
        'Automated FHIR (Fast Healthcare Interoperability Resources) v4 API connector for direct EHR synchronization.'
      ]
    };

    this.data = {
      users: [defaultUser],
      patients,
      datasets: [sampleDataset],
      models: [sampleModel],
      reports: [sampleReport],
      password_reset_tokens: []
    };

    this.save();
  }

  public save() {
    try {
      fs.writeFileSync(DB_FILE, JSON.stringify(this.data, null, 2), 'utf-8');
    } catch (err) {
      console.error('Failed to write database file:', err);
    }
  }

  public get users() { return this.data.users; }
  public get patients() { return this.data.patients; }
  public get datasets() { return this.data.datasets; }
  public get models() { return this.data.models; }
  public get reports() { return this.data.reports; }
  public get tokens() { return this.data.password_reset_tokens; }
}

export const db = new Database();
