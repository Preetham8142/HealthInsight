import fs from 'fs';
import path from 'path';

export interface PatientRecord {
  id: string;
  patient_id: string;
  name: string;
  age: number;
  gender: 'Male' | 'Female' | 'Other';
  height_cm: number;
  weight_kg: number;
  bmi: number;
  blood_pressure: string;
  systolic_bp: number;
  diastolic_bp: number;
  heart_rate: number;
  glucose_level: number;
  cholesterol: number;
  diagnosis: string;
  treatment: string;
  department: string;
  admission_date: string;
  discharge_date: string;
  length_of_stay: number;
  medical_expense: number;
  risk_level: 'Low' | 'Moderate' | 'High';
  readmitted: number;
}

const FIRST_NAMES_MALE = [
  'James', 'Robert', 'John', 'Michael', 'David', 'William', 'Richard', 'Joseph', 'Thomas', 'Charles',
  'Daniel', 'Matthew', 'Anthony', 'Mark', 'Donald', 'Steven', 'Paul', 'Andrew', 'Joshua', 'Kenneth',
  'Kevin', 'Brian', 'George', 'Timothy', 'Ronald', 'Jason', 'Edward', 'Jeffrey', 'Ryan', 'Jacob',
  'Gary', 'Nicholas', 'Eric', 'Jonathan', 'Stephen', 'Larry', 'Justin', 'Scott', 'Brandon', 'Benjamin',
  'Samuel', 'Frank', 'Gregory', 'Raymond', 'Alexander', 'Patrick', 'Jack', 'Dennis', 'Jerry', 'Tyler'
];

const FIRST_NAMES_FEMALE = [
  'Mary', 'Patricia', 'Jennifer', 'Linda', 'Elizabeth', 'Barbara', 'Susan', 'Jessica', 'Sarah', 'Karen',
  'Lisa', 'Nancy', 'Betty', 'Margaret', 'Sandra', 'Ashley', 'Kimberly', 'Emily', 'Donna', 'Michelle',
  'Carol', 'Amanda', 'Melissa', 'Deborah', 'Stephanie', 'Rebecca', 'Sharon', 'Laura', 'Cynthia', 'Kathleen',
  'Amy', 'Angela', 'Shirley', 'Anna', 'Brenda', 'Pamela', 'Emma', 'Nicole', 'Helen', 'Samantha',
  'Katherine', 'Christine', 'Debra', 'Rachel', 'Carolyn', 'Janet', 'Catherine', 'Maria', 'Heather', 'Diane'
];

const LAST_NAMES = [
  'Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Garcia', 'Miller', 'Davis', 'Rodriguez', 'Martinez',
  'Hernandez', 'Lopez', 'Gonzalez', 'Wilson', 'Anderson', 'Thomas', 'Taylor', 'Moore', 'Jackson', 'Martin',
  'Lee', 'Perez', 'Thompson', 'White', 'Harris', 'Sanchez', 'Clark', 'Ramirez', 'Lewis', 'Robinson',
  'Walker', 'Young', 'Allen', 'King', 'Wright', 'Scott', 'Torres', 'Nguyen', 'Hill', 'Flores',
  'Green', 'Adams', 'Nelson', 'Baker', 'Hall', 'Rivera', 'Campbell', 'Mitchell', 'Carter', 'Roberts'
];

const DIAGNOSES_CONFIG = [
  { diagnosis: 'Hypertension', department: 'Cardiology', treatment: 'ACE Inhibitors & Lifestyle', baseCost: 4500, riskMultiplier: 1.2 },
  { diagnosis: 'Type 2 Diabetes', department: 'Endocrinology', treatment: 'Metformin & Insulin Therapy', baseCost: 6200, riskMultiplier: 1.4 },
  { diagnosis: 'Coronary Artery Disease', department: 'Cardiology', treatment: 'Beta-Blockers & Stent Protocol', baseCost: 18500, riskMultiplier: 2.1 },
  { diagnosis: 'Asthma', department: 'Pulmonology', treatment: 'Corticosteroids & Bronchodilators', baseCost: 3800, riskMultiplier: 0.9 },
  { diagnosis: 'Chronic Kidney Disease', department: 'Nephrology', treatment: 'Dialysis & Renal Management', baseCost: 24000, riskMultiplier: 2.4 },
  { diagnosis: 'Pneumonia', department: 'Pulmonology', treatment: 'IV Antibiotic Course & O2', baseCost: 7800, riskMultiplier: 1.5 },
  { diagnosis: 'Heart Failure', department: 'Cardiology', treatment: 'Diuretics & Cardiac Resync', baseCost: 26500, riskMultiplier: 2.6 },
  { diagnosis: 'Osteoarthritis', department: 'Orthopedics', treatment: 'NSAIDs & Physical Therapy', baseCost: 5100, riskMultiplier: 0.8 },
  { diagnosis: 'Gastroenteritis', department: 'Internal Medicine', treatment: 'Rehydration & Anti-emetics', baseCost: 2900, riskMultiplier: 0.7 },
  { diagnosis: 'Acute Bronchitis', department: 'Internal Medicine', treatment: 'Supportive Care & Inhalers', baseCost: 2400, riskMultiplier: 0.6 }
];

export function generateSyntheticPatients(count = 1200): PatientRecord[] {
  const records: PatientRecord[] = [];
  const baseDate = new Date(2025, 0, 15);

  // Seeded deterministic random for consistent reproducibility
  let seed = 42;
  function rand() {
    seed = (seed * 9301 + 49297) % 233280;
    return seed / 233280;
  }

  function randRange(min: number, max: number): number {
    return Math.floor(rand() * (max - min + 1)) + min;
  }

  for (let i = 1; i <= count; i++) {
    const isMale = rand() > 0.48;
    const isOther = rand() < 0.02;
    const gender: 'Male' | 'Female' | 'Other' = isOther ? 'Other' : isMale ? 'Male' : 'Female';
    
    const firstName = isMale
      ? FIRST_NAMES_MALE[Math.floor(rand() * FIRST_NAMES_MALE.length)]
      : FIRST_NAMES_FEMALE[Math.floor(rand() * FIRST_NAMES_FEMALE.length)];
    const lastName = LAST_NAMES[Math.floor(rand() * LAST_NAMES.length)];
    const name = `${firstName} ${lastName}`;

    const age = randRange(19, 86);
    const height_cm = isMale ? randRange(162, 193) : randRange(150, 178);
    const height_m = height_cm / 100;
    const targetBMI = randRange(19, 41) + Math.round(rand() * 10) / 10;
    const weight_kg = Math.round(targetBMI * height_m * height_m);
    const bmi = Number((weight_kg / (height_m * height_m)).toFixed(1));

    // Blood pressure correlated with age and BMI
    const bpBase = 100 + Math.floor(age * 0.45) + Math.floor((bmi - 22) * 1.1);
    const systolic_bp = Math.max(95, Math.min(185, bpBase + randRange(-12, 18)));
    const diastolic_bp = Math.max(58, Math.min(108, Math.floor(systolic_bp * 0.62) + randRange(-6, 10)));
    const blood_pressure = `${systolic_bp}/${diastolic_bp}`;

    const heart_rate = randRange(56, 105);

    // Glucose correlated with BMI and age
    const glucoseBase = 75 + Math.floor((bmi > 27 ? (bmi - 25) * 3.5 : 0)) + (age > 50 ? 15 : 0);
    const glucose_level = Math.max(68, Math.min(270, glucoseBase + randRange(-15, 45)));

    // Cholesterol
    const cholBase = 145 + Math.floor(age * 0.8) + Math.floor((bmi - 22) * 1.5);
    const cholesterol = Math.max(130, Math.min(310, cholBase + randRange(-25, 35)));

    // Clinical diagnosis
    let diagItem = DIAGNOSES_CONFIG[Math.floor(rand() * DIAGNOSES_CONFIG.length)];
    // Make hypertension/diabetes/CAD more likely for elevated vitals
    if (systolic_bp > 145 || diastolic_bp > 92) {
      if (rand() > 0.4) diagItem = DIAGNOSES_CONFIG[0]; // Hypertension
    }
    if (glucose_level > 140) {
      if (rand() > 0.35) diagItem = DIAGNOSES_CONFIG[1]; // Type 2 Diabetes
    }
    if (age > 60 && (systolic_bp > 150 || cholesterol > 240)) {
      if (rand() > 0.5) diagItem = rand() > 0.5 ? DIAGNOSES_CONFIG[2] : DIAGNOSES_CONFIG[6]; // CAD or Heart Failure
    }

    // Admission dates spread over past 12-14 months
    const dayOffset = Math.floor(rand() * 410);
    const admission = new Date(baseDate.getTime() + dayOffset * 24 * 60 * 60 * 1000);
    const length_of_stay = Math.max(1, Math.min(24, Math.round(diagItem.riskMultiplier * randRange(2, 7) + (age > 65 ? 2 : 0))));
    const discharge = new Date(admission.getTime() + length_of_stay * 24 * 60 * 60 * 1000);

    const medical_expense = Math.round(diagItem.baseCost * (1 + (length_of_stay * 0.12)) + randRange(-400, 1800));

    // Calculate clinical risk level
    let riskScore = 0;
    if (age > 60) riskScore += 2;
    else if (age > 45) riskScore += 1;

    if (bmi >= 32) riskScore += 2;
    else if (bmi >= 28) riskScore += 1;

    if (systolic_bp >= 145 || diastolic_bp >= 92) riskScore += 2;
    else if (systolic_bp >= 130 || diastolic_bp >= 85) riskScore += 1;

    if (glucose_level >= 140) riskScore += 2;
    else if (glucose_level >= 110) riskScore += 1;

    if (cholesterol >= 240) riskScore += 1;
    if (diagItem.diagnosis === 'Heart Failure' || diagItem.diagnosis === 'Coronary Artery Disease' || diagItem.diagnosis === 'Chronic Kidney Disease') {
      riskScore += 3;
    }

    const risk_level: 'Low' | 'Moderate' | 'High' = riskScore >= 5 ? 'High' : riskScore >= 3 ? 'Moderate' : 'Low';
    const readmitted = risk_level === 'High' ? (rand() > 0.45 ? 1 : 0) : (rand() > 0.88 ? 1 : 0);

    const pad = String(i).padStart(4, '0');
    records.push({
      id: `pat_${pad}`,
      patient_id: `PID-${1000 + i}`,
      name,
      age,
      gender,
      height_cm,
      weight_kg,
      bmi,
      blood_pressure,
      systolic_bp,
      diastolic_bp,
      heart_rate,
      glucose_level,
      cholesterol,
      diagnosis: diagItem.diagnosis,
      treatment: diagItem.treatment,
      department: diagItem.department,
      admission_date: admission.toISOString().split('T')[0],
      discharge_date: discharge.toISOString().split('T')[0],
      length_of_stay,
      medical_expense,
      risk_level,
      readmitted
    });
  }

  return records;
}

export function saveSampleDataToCSV(records: PatientRecord[], filePath: string) {
  const headers = [
    'patient_id',
    'name',
    'age',
    'gender',
    'height_cm',
    'weight_kg',
    'bmi',
    'blood_pressure',
    'systolic_bp',
    'diastolic_bp',
    'heart_rate',
    'glucose_level',
    'cholesterol',
    'diagnosis',
    'treatment',
    'department',
    'admission_date',
    'discharge_date',
    'length_of_stay',
    'medical_expense',
    'risk_level',
    'readmitted'
  ];

  const rows = records.map(r => [
    r.patient_id,
    `"${r.name}"`,
    r.age,
    r.gender,
    r.height_cm,
    r.weight_kg,
    r.bmi,
    `"${r.blood_pressure}"`,
    r.systolic_bp,
    r.diastolic_bp,
    r.heart_rate,
    r.glucose_level,
    r.cholesterol,
    `"${r.diagnosis}"`,
    `"${r.treatment}"`,
    `"${r.department}"`,
    r.admission_date,
    r.discharge_date,
    r.length_of_stay,
    r.medical_expense,
    r.risk_level,
    r.readmitted
  ].join(','));

  const csvContent = [headers.join(','), ...rows].join('\n');
  const dir = path.dirname(filePath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  fs.writeFileSync(filePath, csvContent, 'utf-8');
}
