import { PatientRecord } from './dataGenerator.js';

export interface ColumnStats {
  column: string;
  count: number;
  mean: number;
  median: number;
  min: number;
  max: number;
  std: number;
  q1: number;
  q3: number;
}

export interface DiseaseDistribution {
  diagnosis: string;
  count: number;
  percentage: number;
  avg_cost: number;
  avg_stay: number;
  high_risk_ratio: number;
}

export interface DemographicsSummary {
  gender_breakdown: { gender: string; count: number; percentage: number }[];
  age_groups: { group: string; count: number; percentage: number; avg_bmi: number }[];
  total_count: number;
  avg_age: number;
}

export interface MonthlyTrend {
  month: string;
  admissions: number;
  avg_stay: number;
  total_expense: number;
  avg_expense: number;
}

export function computeSummaryStatistics(records: PatientRecord[]): Record<string, ColumnStats> {
  const numericFields: (keyof PatientRecord)[] = [
    'age', 'height_cm', 'weight_kg', 'bmi', 'systolic_bp',
    'diastolic_bp', 'heart_rate', 'glucose_level', 'cholesterol',
    'length_of_stay', 'medical_expense'
  ];

  const results: Record<string, ColumnStats> = {};

  for (const field of numericFields) {
    const values = records
      .map(r => Number(r[field]))
      .filter(v => !isNaN(v))
      .sort((a, b) => a - b);

    if (values.length === 0) continue;

    const count = values.length;
    const min = values[0];
    const max = values[count - 1];
    const sum = values.reduce((acc, curr) => acc + curr, 0);
    const mean = Number((sum / count).toFixed(2));

    const mid = Math.floor(count / 2);
    const median = count % 2 === 0
      ? Number(((values[mid - 1] + values[mid]) / 2).toFixed(2))
      : Number(values[mid].toFixed(2));

    const q1Idx = Math.floor(count * 0.25);
    const q3Idx = Math.floor(count * 0.75);
    const q1 = Number(values[q1Idx].toFixed(2));
    const q3 = Number(values[q3Idx].toFixed(2));

    const variance = values.reduce((acc, v) => acc + Math.pow(v - mean, 2), 0) / count;
    const std = Number(Math.sqrt(variance).toFixed(2));

    results[field] = {
      column: field,
      count,
      mean,
      median,
      min,
      max,
      std,
      q1,
      q3
    };
  }

  return results;
}

export function computeDiseaseDistribution(records: PatientRecord[]): DiseaseDistribution[] {
  const map = new Map<string, { count: number; totalCost: number; totalStay: number; highRiskCount: number }>();

  for (const r of records) {
    const diag = r.diagnosis || 'Unspecified';
    const curr = map.get(diag) || { count: 0, totalCost: 0, totalStay: 0, highRiskCount: 0 };
    curr.count += 1;
    curr.totalCost += Number(r.medical_expense) || 0;
    curr.totalStay += Number(r.length_of_stay) || 0;
    if (r.risk_level === 'High') curr.highRiskCount += 1;
    map.set(diag, curr);
  }

  const total = records.length || 1;
  const list: DiseaseDistribution[] = [];

  for (const [diagnosis, stats] of map.entries()) {
    list.push({
      diagnosis,
      count: stats.count,
      percentage: Number(((stats.count / total) * 100).toFixed(1)),
      avg_cost: Math.round(stats.totalCost / stats.count),
      avg_stay: Number((stats.totalStay / stats.count).toFixed(1)),
      high_risk_ratio: Number(((stats.highRiskCount / stats.count) * 100).toFixed(1))
    });
  }

  return list.sort((a, b) => b.count - a.count);
}

export function computeDemographics(records: PatientRecord[]): DemographicsSummary {
  const total = records.length || 1;
  let sumAge = 0;

  const genderMap: Record<string, number> = { Male: 0, Female: 0, Other: 0 };
  const ageBuckets = [
    { label: '<30', min: 0, max: 29, count: 0, bmiSum: 0 },
    { label: '30-44', min: 30, max: 44, count: 0, bmiSum: 0 },
    { label: '45-59', min: 45, max: 59, count: 0, bmiSum: 0 },
    { label: '60-74', min: 60, max: 74, count: 0, bmiSum: 0 },
    { label: '75+', min: 75, max: 120, count: 0, bmiSum: 0 }
  ];

  for (const r of records) {
    sumAge += r.age;
    const g = r.gender || 'Other';
    genderMap[g] = (genderMap[g] || 0) + 1;

    for (const b of ageBuckets) {
      if (r.age >= b.min && r.age <= b.max) {
        b.count += 1;
        b.bmiSum += r.bmi;
        break;
      }
    }
  }

  const gender_breakdown = Object.entries(genderMap).map(([gender, count]) => ({
    gender,
    count,
    percentage: Number(((count / total) * 100).toFixed(1))
  }));

  const age_groups = ageBuckets.map(b => ({
    group: b.label,
    count: b.count,
    percentage: Number(((b.count / total) * 100).toFixed(1)),
    avg_bmi: b.count > 0 ? Number((b.bmiSum / b.count).toFixed(1)) : 0
  }));

  return {
    total_count: records.length,
    avg_age: Number((sumAge / total).toFixed(1)),
    gender_breakdown,
    age_groups
  };
}

export function computePearsonCorrelation(records: PatientRecord[]) {
  const fields: (keyof PatientRecord)[] = [
    'age', 'bmi', 'systolic_bp', 'diastolic_bp',
    'heart_rate', 'glucose_level', 'cholesterol',
    'length_of_stay', 'medical_expense'
  ];

  const fieldLabels: Record<string, string> = {
    age: 'Age',
    bmi: 'BMI',
    systolic_bp: 'Systolic BP',
    diastolic_bp: 'Diastolic BP',
    heart_rate: 'Heart Rate',
    glucose_level: 'Glucose',
    cholesterol: 'Cholesterol',
    length_of_stay: 'Stay (Days)',
    medical_expense: 'Expense ($)'
  };

  const matrix: { x: string; y: string; correlation: number }[] = [];

  for (let i = 0; i < fields.length; i++) {
    for (let j = 0; j < fields.length; j++) {
      const f1 = fields[i];
      const f2 = fields[j];

      if (i === j) {
        matrix.push({ x: fieldLabels[f1], y: fieldLabels[f2], correlation: 1.0 });
        continue;
      }

      const pairs = records
        .map(r => ({ x: Number(r[f1]), y: Number(r[f2]) }))
        .filter(p => !isNaN(p.x) && !isNaN(p.y));

      const n = pairs.length;
      if (n < 2) {
        matrix.push({ x: fieldLabels[f1], y: fieldLabels[f2], correlation: 0 });
        continue;
      }

      let sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0, sumY2 = 0;
      for (const p of pairs) {
        sumX += p.x;
        sumY += p.y;
        sumXY += p.x * p.y;
        sumX2 += p.x * p.x;
        sumY2 += p.y * p.y;
      }

      const numerator = n * sumXY - sumX * sumY;
      const denom = Math.sqrt((n * sumX2 - sumX * sumX) * (n * sumY2 - sumY * sumY));
      const r = denom === 0 ? 0 : Number((numerator / denom).toFixed(3));

      matrix.push({ x: fieldLabels[f1], y: fieldLabels[f2], correlation: r });
    }
  }

  return {
    features: fields.map(f => fieldLabels[f]),
    matrix
  };
}

export function computeMonthlyTrends(records: PatientRecord[]): MonthlyTrend[] {
  const monthMap = new Map<string, { count: number; totalStay: number; totalExpense: number }>();

  for (const r of records) {
    if (!r.admission_date) continue;
    const monthKey = r.admission_date.substring(0, 7); // e.g. "2025-03"
    const curr = monthMap.get(monthKey) || { count: 0, totalStay: 0, totalExpense: 0 };
    curr.count += 1;
    curr.totalStay += Number(r.length_of_stay) || 0;
    curr.totalExpense += Number(r.medical_expense) || 0;
    monthMap.set(monthKey, curr);
  }

  const sortedMonths = Array.from(monthMap.keys()).sort();
  const trends: MonthlyTrend[] = [];

  for (const m of sortedMonths) {
    const val = monthMap.get(m)!;
    trends.push({
      month: m,
      admissions: val.count,
      avg_stay: Number((val.totalStay / val.count).toFixed(1)),
      total_expense: Math.round(val.totalExpense),
      avg_expense: Math.round(val.totalExpense / val.count)
    });
  }

  return trends;
}
