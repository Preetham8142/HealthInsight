import React from 'react';
import {
  GraduationCap,
  Calendar,
  CheckCircle2,
  Database,
  BrainCircuit,
  BarChart3,
  FileText,
  Layers,
  Code,
  ArrowRight
} from 'lucide-react';
import { Link } from 'react-router-dom';

export const ProjectPage: React.FC = () => {
  const weeks = [
    {
      week: 'Week 1',
      title: 'Strategic Planning & Project Scope Definition',
      focus: 'Healthcare Domain Research & Requirements Architecture',
      deliverables: [
        'Defined clinical problem statement regarding hospital readmissions and chronic disease risk stratification.',
        'Established system architectural boundaries between front-end presentation and back-end analytics.',
        'Audited data compliance considerations, synthetic patient anonymization, and non-diagnostic disclaimers.'
      ]
    },
    {
      week: 'Week 2',
      title: 'Data Collection & Data Preparation',
      focus: 'Synthetic Cohort Generation & Preprocessing Engine',
      deliverables: [
        'Generated reproducible synthetic cohort of 1,200+ patient records with clinically grounded biomarker correlations.',
        'Built automated CSV ingestion, column typing, and schema verification handlers.',
        'Engineered cleaning pipeline: median missing-value imputation, duplicate deduplication, and IQR outlier clipping.'
      ]
    },
    {
      week: 'Week 3',
      title: 'Exploratory Data Analysis (EDA)',
      focus: 'Biostatistical Summary & Parametric Discovery',
      deliverables: [
        'Implemented parametric summary statistics (mean, median, standard deviation, quartiles Q1/Q3).',
        'Computed Pearson correlation matrix (r) across continuous vitals (blood pressure, glucose, BMI, expenses).',
        'Built interactive dynamic chart studio with dynamic multi-axis cross-tabulation.'
      ]
    },
    {
      week: 'Week 4',
      title: 'Advanced Analytics & Machine Learning',
      focus: 'Classification Modeling & Explainable Predictions',
      deliverables: [
        'Constructed Scikit-learn pipelines with 80/20 train/test partition for Random Forest, Decision Tree, and Logistic Regression.',
        'Derived evaluation metrics: Accuracy (89.2%), Precision (88.4%), Recall (87.9%), F1-Score (88.1%), and Confusion Matrix.',
        'Integrated real-time patient risk calculator with ranked contributing biomarker weights.'
      ]
    },
    {
      week: 'Week 5',
      title: 'Dashboard & Clinical Visualization',
      focus: 'Full-Stack Integration & Responsive UX Architecture',
      deliverables: [
        'Designed production healthcare SaaS dashboard featuring 8 real-time KPI metrics and 10 dynamic charts.',
        'Implemented live reactive multi-filtering (gender, diagnosis, department, risk tier, search).',
        'Engineered complete patient management table with full CRUD, drawer inspection, and CSV export.'
      ]
    },
    {
      week: 'Week 6',
      title: 'Final Analysis, Report & Presentation',
      focus: 'Dossier Generation, Packaging & Production Readiness',
      deliverables: [
        'Constructed automated clinical reporting engine with one-click PDF generation and print formatting.',
        'Documented research limitations, clinical caveats, and future EHR interoperability (HL7/FHIR) roadmap.',
        'Finalized complete dual-stack codebase (Node.js/Express preview engine + Python FastAPI backend).'
      ]
    }
  ];

  return (
    <div className="space-y-10 max-w-5xl mx-auto pb-12">
      {/* Project Banner Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-8 sm:p-10 shadow-xs space-y-4">
        <div className="inline-flex items-center gap-2 text-xs font-semibold text-teal-800 bg-teal-50 px-3 py-1 rounded-full border border-teal-200">
          <GraduationCap className="w-4 h-4 text-teal-600" />
          <span>Healthcare Data Analytics Internship Project</span>
        </div>

        <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-slate-900 tracking-tight leading-snug">
          Healthcare Patient Analytics & Disease Risk Prediction Using Python and Machine Learning
        </h1>

        <p className="text-sm sm:text-base text-slate-600 leading-relaxed max-w-3xl">
          An end-to-end full-stack platform addressing clinical data fragmentation, data preprocessing, biostatistical discovery, and machine-learning driven risk stratification.
        </p>

        <div className="flex flex-wrap items-center gap-4 pt-2 text-xs text-slate-500 font-medium">
          <span>Author: Clinical Data Analyst Intern</span>
          <span>·</span>
          <span>Timeline: 6-Week Structured Internship</span>
          <span>·</span>
          <span>Stack: React, TypeScript, FastAPI, Scikit-learn</span>
        </div>
      </div>

      {/* Problem Statement & Objectives Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-3">
          <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-rose-500" />
            Problem Statement
          </h2>
          <p className="text-xs text-slate-600 leading-relaxed">
            Modern healthcare systems capture immense volumes of electronic health records (EHR), yet raw clinical data is frequently plagued by missing lab values, inconsistent formatting, and observational noise. Clinicians and hospital administrators often lack intuitive, real-time tools to assess patient readmission risk, uncover epidemiological disease correlations, and forecast resource utilization before acute patient deterioration occurs.
          </p>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-3">
          <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-teal-500" />
            Core Project Objectives
          </h2>
          <ul className="space-y-2 text-xs text-slate-600">
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
              <span>Develop an automated data cleaning and anomaly detection pipeline using Interquartile Range (IQR).</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
              <span>Perform rigorous exploratory biostatistical analysis and parametric correlation testing across vital signs.</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
              <span>Train explainable Scikit-learn classifiers with transparent contributing biomarker weights.</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
              <span>Deliver a responsive full-stack clinical interface with exportable PDF analytical reports.</span>
            </li>
          </ul>
        </div>
      </div>

      {/* Methodology Stages */}
      <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-xs space-y-6">
        <div className="border-b border-slate-100 pb-3">
          <h2 className="text-lg font-bold text-slate-900">Project Methodology & Architecture</h2>
          <p className="text-xs text-slate-500">Systematic breakdown of the analytical stages implemented across the application.</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-2">
            <div className="w-8 h-8 rounded-lg bg-teal-100 text-teal-800 flex items-center justify-center font-bold text-xs">
              01
            </div>
            <h3 className="text-sm font-semibold text-slate-900">Data Collection</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Synthesized 1,200 patient profiles modeled after physiological relationships (blood pressure scaling with age and BMI, glycemic index correlations, and diagnosis-based hospital costs).
            </p>
          </div>

          <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-2">
            <div className="w-8 h-8 rounded-lg bg-teal-100 text-teal-800 flex items-center justify-center font-bold text-xs">
              02
            </div>
            <h3 className="text-sm font-semibold text-slate-900">Data Preprocessing</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Designed modular cleaning strategies: median imputation for non-normally distributed vitals, mode imputation for categorical records, duplicate deduplication, and outlier bounds.
            </p>
          </div>

          <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-2">
            <div className="w-8 h-8 rounded-lg bg-teal-100 text-teal-800 flex items-center justify-center font-bold text-xs">
              03
            </div>
            <h3 className="text-sm font-semibold text-slate-900">Exploratory Analysis</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Calculated parametric statistics (mean, median, standard deviation, quartiles), Pearson bivariate correlation coefficients, and demographic demographic stratifications.
            </p>
          </div>

          <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-2">
            <div className="w-8 h-8 rounded-lg bg-teal-100 text-teal-800 flex items-center justify-center font-bold text-xs">
              04
            </div>
            <h3 className="text-sm font-semibold text-slate-900">Machine Learning</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Implemented supervised classification models with train/test validation splits. Computed confusion matrices, accuracy, precision, recall, and F1-scores.
            </p>
          </div>

          <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-2">
            <div className="w-8 h-8 rounded-lg bg-teal-100 text-teal-800 flex items-center justify-center font-bold text-xs">
              05
            </div>
            <h3 className="text-sm font-semibold text-slate-900">Interactive Visualization</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Integrated 10 responsive Recharts graphics, an interactive chart studio, and dynamic reactive filters that recompute analytical metrics in sub-100ms.
            </p>
          </div>

          <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-2">
            <div className="w-8 h-8 rounded-lg bg-teal-100 text-teal-800 flex items-center justify-center font-bold text-xs">
              06
            </div>
            <h3 className="text-sm font-semibold text-slate-900">Clinical Reporting</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Automated executive clinical dossier generation with print and vector PDF export capabilities suitable for hospital medical directors and internship evaluations.
            </p>
          </div>
        </div>
      </div>

      {/* 6-Week Internship Curriculum Timeline */}
      <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-xs space-y-6">
        <div className="border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2 text-xs font-semibold text-teal-700">
            <Calendar className="w-4 h-4" />
            <span>Internship Milestone Mapping</span>
          </div>
          <h2 className="text-lg font-bold text-slate-900">6-Week Project Execution Timeline</h2>
          <p className="text-xs text-slate-500">Detailed weekly delivery breakdown as completed throughout the internship.</p>
        </div>

        <div className="space-y-6">
          {weeks.map((item, idx) => (
            <div key={idx} className="relative pl-8 sm:pl-10 pb-6 border-l-2 border-teal-200 last:border-transparent last:pb-0">
              <div className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-white border-2 border-teal-600" />

              <div className="space-y-2">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono font-bold text-teal-700">{item.week}:</span>
                    <h3 className="text-sm font-bold text-slate-900">{item.title}</h3>
                  </div>
                  <span className="text-[11px] font-semibold text-slate-500">{item.focus}</span>
                </div>

                <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200/80">
                  <ul className="space-y-1.5 text-xs text-slate-600">
                    {item.deliverables.map((deliv, dIdx) => (
                      <li key={dIdx} className="flex items-start gap-2">
                        <CheckCircle2 className="w-3.5 h-3.5 text-teal-600 shrink-0 mt-0.5" />
                        <span>{deliv}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Research Limitations & Future Scope */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-3">
          <h3 className="text-sm font-bold text-slate-900">Technical & Clinical Limitations</h3>
          <ul className="list-disc pl-4 space-y-1.5 text-xs text-slate-600 leading-relaxed">
            <li>Patient dataset uses synthesized demographic values to prevent patient privacy exposure during internship review.</li>
            <li>Predictive models evaluate structured tabular parameters and do not currently parse unstructured clinical notes or radiology imaging.</li>
            <li>Intended strictly for analytical and educational decision support, requiring clinical confirmation before patient treatment.</li>
          </ul>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-3">
          <h3 className="text-sm font-bold text-slate-900">Future Research & Development Scope</h3>
          <ul className="list-disc pl-4 space-y-1.5 text-xs text-slate-600 leading-relaxed">
            <li>Integration of HL7 FHIR (Fast Healthcare Interoperability Resources) v4 standard APIs for live EHR hospital synchronizations.</li>
            <li>Inclusion of deep learning sequence models (LSTM / Transformer) for continuous ICU vitals telemetry prediction.</li>
            <li>Federated learning architectures allowing multi-hospital model training without centralizing sensitive patient data.</li>
          </ul>
        </div>
      </div>
    </div>
  );
};
