import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { MLModel, PredictionResult, DatasetMeta } from '../types';
import { useToast } from '../context/ToastContext';
import {
  BrainCircuit,
  Sliders,
  Play,
  CheckCircle2,
  AlertTriangle,
  Loader2,
  Activity,
  HeartPulse,
  Scale,
  Sparkles
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid
} from 'recharts';

export const RiskPredictionPage: React.FC = () => {
  const [datasets, setDatasets] = useState<DatasetMeta[]>([]);
  const [models, setModels] = useState<MLModel[]>([]);
  const [activeModel, setActiveModel] = useState<MLModel | null>(null);

  // Training controls
  const [selectedDatasetId, setSelectedDatasetId] = useState<string>('');
  const [modelType, setModelType] = useState<'Random Forest' | 'Decision Tree' | 'Logistic Regression'>('Random Forest');
  const [targetColumn, setTargetColumn] = useState('risk_level');
  const [training, setTraining] = useState(false);

  // Prediction Calculator inputs
  const [age, setAge] = useState<number>(58);
  const [gender, setGender] = useState<string>('Female');
  const [bmi, setBmi] = useState<number>(29.4);
  const [systolicBp, setSystolicBp] = useState<number>(142);
  const [diastolicBp, setDiastolicBp] = useState<number>(88);
  const [heartRate, setHeartRate] = useState<number>(76);
  const [glucose, setGlucose] = useState<number>(138);
  const [cholesterol, setCholesterol] = useState<number>(224);
  const [diagnosis, setDiagnosis] = useState<string>('Type 2 Diabetes');

  const [predicting, setPredicting] = useState(false);
  const [predictionResult, setPredictionResult] = useState<PredictionResult | null>(null);

  const { showToast } = useToast();

  useEffect(() => {
    async function init() {
      try {
        const [dsRes, mdlRes] = await Promise.all([
          api.datasets.getAll(),
          api.ml.getModels()
        ]);
        setDatasets(dsRes.datasets);
        if (dsRes.datasets.length > 0) {
          setSelectedDatasetId(dsRes.datasets[0].id);
        }
        setModels(mdlRes.models);
        if (mdlRes.models.length > 0) {
          setActiveModel(mdlRes.models[0]);
        }
      } catch (err) {
        console.error('Failed to load ML state:', err);
      }
    }
    init();
  }, []);

  const handleTrainModel = async (e: React.FormEvent) => {
    e.preventDefault();
    setTraining(true);
    try {
      const res = await api.ml.train({
        model_type: modelType,
        target_column: targetColumn,
        features: ['age', 'bmi', 'systolic_bp', 'glucose_level', 'cholesterol', 'heart_rate']
      });
      setActiveModel(res.model);
      setModels(prev => [res.model, ...prev]);
      showToast(`Model ${res.model.name} trained with ${(res.model.accuracy * 100).toFixed(1)}% accuracy!`, 'success');
    } catch (err: any) {
      showToast(err.message || 'Model training failed.', 'error');
    } finally {
      setTraining(false);
    }
  };

  const handlePredictRisk = async (e: React.FormEvent) => {
    e.preventDefault();
    setPredicting(true);
    try {
      const res = await api.ml.predict({
        age,
        gender,
        bmi,
        systolic_bp: systolicBp,
        diastolic_bp: diastolicBp,
        heart_rate: heartRate,
        glucose_level: glucose,
        cholesterol,
        diagnosis
      });
      setPredictionResult(res.prediction);
      showToast('Patient risk profile computed.', 'success');
    } catch (err: any) {
      showToast(err.message || 'Risk inference failed.', 'error');
    } finally {
      setPredicting(false);
    }
  };

  const loadSampleCase = (type: 'healthy' | 'moderate' | 'critical') => {
    if (type === 'healthy') {
      setAge(32);
      setGender('Male');
      setBmi(22.8);
      setSystolicBp(118);
      setDiastolicBp(76);
      setHeartRate(68);
      setGlucose(88);
      setCholesterol(165);
      setDiagnosis('Routine Checkup');
    } else if (type === 'moderate') {
      setAge(56);
      setGender('Female');
      setBmi(28.5);
      setSystolicBp(136);
      setDiastolicBp(86);
      setHeartRate(78);
      setGlucose(122);
      setCholesterol(218);
      setDiagnosis('Hypertension');
    } else {
      setAge(71);
      setGender('Male');
      setBmi(34.2);
      setSystolicBp(162);
      setDiastolicBp(98);
      setHeartRate(88);
      setGlucose(185);
      setCholesterol(270);
      setDiagnosis('Coronary Artery Disease');
    }
    setPredictionResult(null);
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
          Patient Risk Stratification & Machine Learning
        </h1>
        <p className="text-xs text-slate-500">
          Train predictive classifiers (Logistic Regression, Decision Tree, Random Forest) and compute patient risk probability.
        </p>
      </div>

      {/* Top Disclaimer Notice */}
      <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-900 flex items-start gap-2.5">
        <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
        <div className="leading-relaxed">
          <span className="font-semibold">Educational & Research Disclaimer: </span>
          This tool is for educational and analytical purposes only and is not a medical diagnosis. All healthcare conclusions must be evaluated by licensed medical physicians.
        </div>
      </div>

      {/* Model Training & Evaluation Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Model Training Control Panel */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
            <BrainCircuit className="w-4 h-4 text-teal-600" />
            <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Train Classification Pipeline
            </h2>
          </div>

          <form onSubmit={handleTrainModel} className="space-y-3 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Dataset Cohort</label>
              <select
                value={selectedDatasetId}
                onChange={e => setSelectedDatasetId(e.target.value)}
                className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white"
              >
                {datasets.map(ds => (
                  <option key={ds.id} value={ds.id}>
                    {ds.name} ({ds.row_count} rows)
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Target Feature</label>
              <select
                value={targetColumn}
                onChange={e => setTargetColumn(e.target.value)}
                className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white"
              >
                <option value="risk_level">risk_level (Multiclass: Low, Moderate, High)</option>
                <option value="readmitted">readmitted (Binary: 0 or 1)</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Algorithm</label>
              <select
                value={modelType}
                onChange={e => setModelType(e.target.value as any)}
                className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white"
              >
                <option value="Random Forest">Random Forest Classifier (Ensemble)</option>
                <option value="Decision Tree">Decision Tree (Gini Impurity Split)</option>
                <option value="Logistic Regression">Logistic Regression (L2 Regularized)</option>
              </select>
            </div>

            <div className="pt-2 text-[11px] text-slate-500 space-y-1">
              <div>Train/Test Split: <span className="font-semibold text-slate-700 font-mono">80% / 20%</span></div>
              <div>Input Vectors: <span className="text-slate-700 font-mono">Age, BMI, BP, Glucose, Chol, HR</span></div>
            </div>

            <button
              type="submit"
              disabled={training}
              className="w-full py-2.5 px-4 text-xs font-semibold text-white bg-teal-600 hover:bg-teal-700 disabled:opacity-60 rounded-lg shadow-xs transition-colors flex items-center justify-center gap-1.5 mt-2"
            >
              {training ? <Loader2 className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4" />}
              <span>{training ? 'Training Model...' : 'Train Model Pipeline'}</span>
            </button>
          </form>
        </div>

        {/* Model Evaluation Metrics Display */}
        <div className="lg:col-span-2 bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-5">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Model Evaluation & Validation
              </h2>
              <p className="text-[11px] text-slate-500 font-mono">
                {activeModel ? activeModel.name : 'Random Forest Classifier'}
              </p>
            </div>
            <div className="flex items-center gap-1 text-[11px] text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-200 font-semibold">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Validated (80/20 Split)</span>
            </div>
          </div>

          {activeModel && (
            <div className="space-y-5">
              {/* 4 Core Scikit-learn Metrics */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div className="bg-slate-50 p-3 rounded-lg border border-slate-100 space-y-0.5">
                  <span className="text-[11px] text-slate-400">Accuracy</span>
                  <div className="text-xl font-bold text-slate-900 font-mono tabular-nums">
                    {(activeModel.accuracy * 100).toFixed(1)}%
                  </div>
                  <div className="text-[10px] text-slate-500">(TP + TN) / Total</div>
                </div>

                <div className="bg-slate-50 p-3 rounded-lg border border-slate-100 space-y-0.5">
                  <span className="text-[11px] text-slate-400">Precision</span>
                  <div className="text-xl font-bold text-slate-900 font-mono tabular-nums">
                    {(activeModel.precision * 100).toFixed(1)}%
                  </div>
                  <div className="text-[10px] text-slate-500">TP / (TP + FP)</div>
                </div>

                <div className="bg-slate-50 p-3 rounded-lg border border-slate-100 space-y-0.5">
                  <span className="text-[11px] text-slate-400">Recall</span>
                  <div className="text-xl font-bold text-slate-900 font-mono tabular-nums">
                    {(activeModel.recall * 100).toFixed(1)}%
                  </div>
                  <div className="text-[10px] text-slate-500">TP / (TP + FN)</div>
                </div>

                <div className="bg-slate-50 p-3 rounded-lg border border-slate-100 space-y-0.5">
                  <span className="text-[11px] text-slate-400">F1-Score</span>
                  <div className="text-xl font-bold text-teal-700 font-mono tabular-nums">
                    {(activeModel.f1_score * 100).toFixed(1)}%
                  </div>
                  <div className="text-[10px] text-slate-500">Harmonic Mean</div>
                </div>
              </div>

              {/* Feature Importance Bar Chart */}
              <div className="space-y-2">
                <h3 className="text-xs font-bold text-slate-800">Biomarker Feature Importance Weights</h3>
                <div className="h-44">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={activeModel.feature_importance}
                      layout="vertical"
                      margin={{ top: 5, right: 20, left: 30, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                      <XAxis type="number" domain={[0, 0.4]} tick={{ fontSize: 10 }} />
                      <YAxis dataKey="feature" type="category" tick={{ fontSize: 10 }} width={80} />
                      <Tooltip
                        formatter={(val: any) => [`${(Number(val) * 100).toFixed(1)}%`, 'Weight']}
                        contentStyle={{ fontSize: '11px', borderRadius: '8px' }}
                      />
                      <Bar dataKey="importance" fill="#0d9488" radius={[0, 4, 4, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Patient Risk Calculator Form & Output */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Input Form */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Patient Risk Calculator</h2>
              <p className="text-xs text-slate-500">Enter clinical biomarkers to evaluate risk stratification.</p>
            </div>
            {/* Quick Demo Pre-fills */}
            <div className="flex items-center gap-1.5 text-[11px]">
              <span className="text-slate-400">Preset:</span>
              <button
                type="button"
                onClick={() => loadSampleCase('healthy')}
                className="px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 hover:bg-emerald-100 font-medium"
              >
                Low
              </button>
              <button
                type="button"
                onClick={() => loadSampleCase('moderate')}
                className="px-2 py-0.5 rounded bg-amber-50 text-amber-700 hover:bg-amber-100 font-medium"
              >
                Moderate
              </button>
              <button
                type="button"
                onClick={() => loadSampleCase('critical')}
                className="px-2 py-0.5 rounded bg-rose-50 text-rose-700 hover:bg-rose-100 font-medium"
              >
                High
              </button>
            </div>
          </div>

          <form onSubmit={handlePredictRisk} className="space-y-4 text-xs">
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Age</label>
                <input
                  type="number"
                  required
                  value={age}
                  onChange={e => setAge(Number(e.target.value))}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 focus:outline-none"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Gender</label>
                <select
                  value={gender}
                  onChange={e => setGender(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white focus:outline-none"
                >
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </select>
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">BMI (kg/m²)</label>
                <input
                  type="number"
                  step="0.1"
                  required
                  value={bmi}
                  onChange={e => setBmi(Number(e.target.value))}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Systolic BP (mmHg)</label>
                <input
                  type="number"
                  required
                  value={systolicBp}
                  onChange={e => setSystolicBp(Number(e.target.value))}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 focus:outline-none"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Diastolic BP (mmHg)</label>
                <input
                  type="number"
                  required
                  value={diastolicBp}
                  onChange={e => setDiastolicBp(Number(e.target.value))}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 focus:outline-none"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Heart Rate (bpm)</label>
                <input
                  type="number"
                  required
                  value={heartRate}
                  onChange={e => setHeartRate(Number(e.target.value))}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Fasting Glucose (mg/dL)</label>
                <input
                  type="number"
                  required
                  value={glucose}
                  onChange={e => setGlucose(Number(e.target.value))}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 focus:outline-none"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Cholesterol (mg/dL)</label>
                <input
                  type="number"
                  required
                  value={cholesterol}
                  onChange={e => setCholesterol(Number(e.target.value))}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Diagnosis Context</label>
              <input
                type="text"
                value={diagnosis}
                onChange={e => setDiagnosis(e.target.value)}
                className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 focus:outline-none"
              />
            </div>

            <button
              type="submit"
              disabled={predicting}
              className="w-full py-2.5 px-4 text-xs font-semibold text-white bg-teal-600 hover:bg-teal-700 disabled:opacity-60 rounded-lg shadow-xs transition-colors flex items-center justify-center gap-2"
            >
              {predicting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
              <span>{predicting ? 'Analyzing Risk Profile...' : 'Analyze Risk'}</span>
            </button>
          </form>
        </div>

        {/* Prediction Results Display */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-5">
          <div className="border-b border-slate-100 pb-3">
            <h2 className="text-sm font-bold text-slate-900">Clinical Risk Prediction Result</h2>
            <p className="text-xs text-slate-500">Multivariate model outcome with probability distribution.</p>
          </div>

          {!predictionResult ? (
            <div className="min-h-[280px] flex flex-col items-center justify-center text-center p-6 space-y-2 text-slate-400">
              <Activity className="w-8 h-8 text-slate-300" />
              <p className="text-xs">
                Enter patient biomarkers on the left and click "Analyze Risk" to inspect predicted probability distribution and contributing factors.
              </p>
            </div>
          ) : (
            <div className="space-y-5">
              {/* Risk Level Badge & Score */}
              <div className={`p-4 rounded-xl border flex items-center justify-between ${
                predictionResult.risk_level === 'High'
                  ? 'bg-rose-50 border-rose-200 text-rose-900'
                  : predictionResult.risk_level === 'Moderate'
                  ? 'bg-amber-50 border-amber-200 text-amber-900'
                  : 'bg-emerald-50 border-emerald-200 text-emerald-900'
              }`}>
                <div>
                  <div className="text-[11px] uppercase tracking-wider font-semibold opacity-75">
                    Predicted Risk Category
                  </div>
                  <div className="text-2xl font-extrabold">
                    {predictionResult.risk_level} Risk
                  </div>
                  <div className="text-xs mt-0.5">
                    Model Confidence: <span className="font-semibold">{predictionResult.confidence}%</span>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-2xl font-extrabold font-mono tabular-nums">
                    {predictionResult.risk_score}
                    <span className="text-xs font-normal opacity-70"> / 100</span>
                  </div>
                  <div className="text-[11px] opacity-75">Composite Risk Index</div>
                </div>
              </div>

              {/* Class Probabilities Bar */}
              <div className="space-y-1.5 text-xs">
                <div className="flex justify-between text-slate-600 font-medium">
                  <span>Class Probability Distribution</span>
                  <span className="font-mono text-[11px]">
                    Low: {(predictionResult.probabilities.low * 100).toFixed(0)}% · Mod: {(predictionResult.probabilities.moderate * 100).toFixed(0)}% · High: {(predictionResult.probabilities.high * 100).toFixed(0)}%
                  </span>
                </div>
                <div className="flex h-2.5 rounded-full overflow-hidden bg-slate-100">
                  <div
                    style={{ width: `${predictionResult.probabilities.low * 100}%` }}
                    className="bg-emerald-500 transition-all duration-500"
                    title={`Low: ${(predictionResult.probabilities.low * 100).toFixed(0)}%`}
                  />
                  <div
                    style={{ width: `${predictionResult.probabilities.moderate * 100}%` }}
                    className="bg-amber-500 transition-all duration-500"
                    title={`Moderate: ${(predictionResult.probabilities.moderate * 100).toFixed(0)}%`}
                  />
                  <div
                    style={{ width: `${predictionResult.probabilities.high * 100}%` }}
                    className="bg-rose-500 transition-all duration-500"
                    title={`High: ${(predictionResult.probabilities.high * 100).toFixed(0)}%`}
                  />
                </div>
              </div>

              {/* Contributing Features */}
              <div className="space-y-2">
                <h3 className="text-xs font-bold text-slate-900">Ranked Contributing Clinical Biomarkers</h3>
                <div className="space-y-2">
                  {predictionResult.contributing_factors.map((factor, idx) => (
                    <div
                      key={idx}
                      className="p-2.5 rounded-lg border border-slate-200/80 bg-slate-50/50 flex items-start justify-between gap-3 text-xs"
                    >
                      <div className="space-y-0.5">
                        <div className="font-semibold text-slate-800">{factor.factor}</div>
                        <div className="text-[11px] text-slate-500 leading-snug">{factor.explanation}</div>
                      </div>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-semibold shrink-0 ${
                        factor.impact === 'High' ? 'bg-rose-100 text-rose-800' : 'bg-amber-100 text-amber-800'
                      }`}>
                        +{factor.weight}% impact
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Recommendations */}
              <div className="space-y-1.5 text-xs">
                <h3 className="font-bold text-slate-900">Recommended Clinical Actions</h3>
                <ul className="list-disc pl-4 space-y-1 text-slate-600">
                  {predictionResult.clinical_recommendations.map((rec, i) => (
                    <li key={i}>{rec}</li>
                  ))}
                </ul>
              </div>

              {/* Mandatory Disclaimer Box */}
              <div className="p-3 rounded-lg bg-slate-100 text-[11px] text-slate-600 leading-relaxed border border-slate-200">
                {predictionResult.disclaimer}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
