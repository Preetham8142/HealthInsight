import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { ReportRecord } from '../types';
import { useToast } from '../context/ToastContext';
import {
  FileText,
  Download,
  Plus,
  Calendar,
  CheckCircle2,
  Printer,
  Shield,
  Activity,
  Loader2,
  ChevronRight
} from 'lucide-react';
import jsPDF from 'jspdf';

export const ReportsPage: React.FC = () => {
  const [reports, setReports] = useState<ReportRecord[]>([]);
  const [selectedReport, setSelectedReport] = useState<ReportRecord | null>(null);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);

  const { showToast } = useToast();

  const fetchReports = async () => {
    try {
      setLoading(true);
      const res = await api.reports.getAll();
      setReports(res.reports);
      if (res.reports.length > 0 && !selectedReport) {
        setSelectedReport(res.reports[0]);
      }
    } catch (err: any) {
      showToast('Failed to load reports archive.', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReports();
  }, []);

  const handleGenerateReport = async () => {
    setGenerating(true);
    try {
      const res = await api.reports.generate({
        title: `Comprehensive Inpatient Analytics & Risk Stratification Dossier`
      });
      setSelectedReport(res.report);
      setReports(prev => [res.report, ...prev]);
      showToast('Clinical analytical report generated successfully!', 'success');
    } catch (err: any) {
      showToast('Error generating report.', 'error');
    } finally {
      setGenerating(false);
    }
  };

  const handleDownloadPDF = () => {
    if (!selectedReport) return;

    try {
      const doc = new jsPDF();
      doc.setFont('helvetica');

      // Title & Header
      doc.setFontSize(18);
      doc.setTextColor(13, 148, 136); // Teal
      doc.text('HealthInsight Clinical Analytics Report', 14, 20);

      doc.setFontSize(10);
      doc.setTextColor(100, 116, 139);
      doc.text(`Report ID: ${selectedReport.id} | Generated: ${new Date(selectedReport.created_at).toLocaleDateString()}`, 14, 28);
      doc.text(`Cohort: ${selectedReport.dataset_name}`, 14, 34);

      // Horizontal line
      doc.setDrawColor(226, 232, 240);
      doc.line(14, 38, 196, 38);

      // Summary Statistics Section
      doc.setFontSize(13);
      doc.setTextColor(15, 23, 42);
      doc.text('1. Executive Clinical Summary', 14, 48);

      doc.setFontSize(10);
      doc.setTextColor(51, 65, 85);
      doc.text(`• Total Inpatient Cohort: ${selectedReport.summary.total_patients} patients`, 18, 56);
      doc.text(`• Mean Patient Age: ${selectedReport.summary.avg_age} years`, 18, 62);
      doc.text(`• High Risk Patients Identified: ${selectedReport.summary.high_risk_patients} (${((selectedReport.summary.high_risk_patients / selectedReport.summary.total_patients) * 100).toFixed(1)}%)`, 18, 68);
      doc.text(`• Average Hospital Stay: ${selectedReport.summary.avg_stay} days`, 18, 74);
      doc.text(`• Mean Treatment Expenditure: $${selectedReport.summary.avg_expense.toLocaleString()} USD`, 18, 80);
      doc.text(`• Machine Learning Accuracy: ${selectedReport.summary.model_accuracy}%`, 18, 86);

      // EDA Findings
      doc.setFontSize(13);
      doc.setTextColor(15, 23, 42);
      doc.text('2. Key Exploratory Findings', 14, 98);

      doc.setFontSize(9);
      doc.setTextColor(71, 85, 105);
      let y = 106;
      selectedReport.eda_findings.forEach((finding, idx) => {
        doc.text(`${idx + 1}. ${finding}`, 18, y, { maxWidth: 175 });
        y += 10;
      });

      // Machine Learning Validation
      y += 4;
      doc.setFontSize(13);
      doc.setTextColor(15, 23, 42);
      doc.text('3. Machine Learning Model Validation', 14, y);
      y += 8;

      doc.setFontSize(9);
      doc.setTextColor(71, 85, 105);
      doc.text(`Model Architecture: ${selectedReport.model_metrics.model_name}`, 18, y);
      y += 6;
      doc.text(`Accuracy: ${selectedReport.model_metrics.accuracy}% | F1-Score: ${selectedReport.model_metrics.f1_score}%`, 18, y);
      y += 6;
      doc.text(`Precision: ${selectedReport.model_metrics.precision}% | Recall: ${selectedReport.model_metrics.recall}%`, 18, y);
      y += 12;

      // Clinical Recommendations
      doc.setFontSize(13);
      doc.setTextColor(15, 23, 42);
      doc.text('4. Strategic Clinical Recommendations', 14, y);
      y += 8;

      doc.setFontSize(9);
      selectedReport.recommendations.forEach((rec, idx) => {
        doc.text(`• ${rec}`, 18, y, { maxWidth: 175 });
        y += 8;
      });

      // Disclaimer
      y += 8;
      doc.setFontSize(8);
      doc.setTextColor(148, 163, 184);
      doc.text('Disclaimer: For educational, clinical research, and data analytics demonstration purposes only.', 14, y);

      doc.save(`HealthInsight_Report_${selectedReport.id}.pdf`);
      showToast('PDF downloaded successfully!', 'success');
    } catch (err) {
      console.error(err);
      window.print();
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      <div className="no-print flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            Clinical Analytics & Risk Reports
          </h1>
          <p className="text-xs text-slate-500">
            Generate, preview, and download formal executive healthcare analytics dossiers.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={handleGenerateReport}
            disabled={generating}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-teal-600 hover:bg-teal-700 disabled:opacity-60 rounded-lg shadow-xs transition-colors"
          >
            {generating ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Plus className="w-3.5 h-3.5" />}
            <span>Generate New Report</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Left Column: Reports List */}
        <div className="no-print bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-4">
          <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
            Report Archives ({reports.length})
          </h2>

          <div className="space-y-2">
            {reports.map(r => {
              const isSelected = selectedReport?.id === r.id;
              return (
                <div
                  key={r.id}
                  onClick={() => setSelectedReport(r)}
                  className={`p-3 rounded-lg border cursor-pointer transition-all ${
                    isSelected
                      ? 'border-teal-500 bg-teal-50/40 shadow-xs'
                      : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                  }`}
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-1.5">
                      <FileText className="w-4 h-4 text-teal-600 shrink-0" />
                      <span className="font-semibold text-xs text-slate-900 line-clamp-1">
                        {r.title}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-500 flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {new Date(r.created_at).toLocaleDateString()}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Formal Report Preview Dossier */}
        <div className="lg:col-span-3 space-y-6">
          {selectedReport && (
            <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-8 sm:p-10 space-y-8 print:p-0 print:border-none print:shadow-none">
              {/* Report Header */}
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 border-b border-slate-200 pb-6">
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-teal-700 font-semibold text-xs">
                    <Activity className="w-4 h-4" />
                    <span>HealthInsight Clinical Analytics Report</span>
                  </div>
                  <h2 className="text-2xl font-bold text-slate-900 tracking-tight leading-snug">
                    {selectedReport.title}
                  </h2>
                  <div className="text-xs text-slate-500 flex flex-wrap gap-3">
                    <span>Cohort: {selectedReport.dataset_name}</span>
                    <span>·</span>
                    <span>Date: {new Date(selectedReport.created_at).toLocaleDateString(undefined, { dateStyle: 'long' })}</span>
                    <span>·</span>
                    <span>Doc ID: {selectedReport.id}</span>
                  </div>
                </div>

                <div className="no-print flex items-center gap-2 shrink-0">
                  <button
                    onClick={handlePrint}
                    className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>Print</span>
                  </button>
                  <button
                    onClick={handleDownloadPDF}
                    className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-teal-600 hover:bg-teal-700 rounded-lg shadow-xs transition-colors"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download PDF</span>
                  </button>
                </div>
              </div>

              {/* 1. Executive Summary Table */}
              <div className="space-y-3">
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  01. Executive Cohort Summary
                </h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
                  <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100 space-y-0.5">
                    <span className="text-[11px] text-slate-400">Total Patients</span>
                    <div className="text-xl font-bold text-slate-900 tabular-nums font-mono">
                      {selectedReport.summary.total_patients}
                    </div>
                  </div>
                  <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100 space-y-0.5">
                    <span className="text-[11px] text-slate-400">Mean Cohort Age</span>
                    <div className="text-xl font-bold text-slate-900 tabular-nums font-mono">
                      {selectedReport.summary.avg_age} yrs
                    </div>
                  </div>
                  <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100 space-y-0.5">
                    <span className="text-[11px] text-slate-400">High Risk Subgroup</span>
                    <div className="text-xl font-bold text-rose-600 tabular-nums font-mono">
                      {selectedReport.summary.high_risk_patients}
                    </div>
                  </div>
                  <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100 space-y-0.5">
                    <span className="text-[11px] text-slate-400">Mean Length of Stay</span>
                    <div className="text-xl font-bold text-slate-900 tabular-nums font-mono">
                      {selectedReport.summary.avg_stay} days
                    </div>
                  </div>
                  <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100 space-y-0.5">
                    <span className="text-[11px] text-slate-400">Mean Expenditure</span>
                    <div className="text-xl font-bold text-slate-900 tabular-nums font-mono">
                      ${selectedReport.summary.avg_expense.toLocaleString()}
                    </div>
                  </div>
                  <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100 space-y-0.5">
                    <span className="text-[11px] text-slate-400">Prediction Accuracy</span>
                    <div className="text-xl font-bold text-teal-700 tabular-nums font-mono">
                      {selectedReport.summary.model_accuracy}%
                    </div>
                  </div>
                </div>
              </div>

              {/* 2. Key Exploratory Findings */}
              <div className="space-y-3">
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  02. Exploratory Data Findings (EDA)
                </h3>
                <div className="space-y-2">
                  {selectedReport.eda_findings.map((finding, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded-lg border border-slate-200/80 bg-slate-50/40 text-xs text-slate-700 flex items-start gap-2.5"
                    >
                      <span className="font-mono font-bold text-teal-700">0{idx + 1}.</span>
                      <span className="leading-relaxed">{finding}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* 3. Predictive Model Validation */}
              <div className="space-y-3">
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  03. Machine Learning Model Metrics
                </h3>
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-slate-800">
                      Classifier: {selectedReport.model_metrics.model_name}
                    </span>
                    <span className="text-emerald-700 font-semibold text-[11px]">80/20 Test Partition</span>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
                    <div className="bg-white p-2.5 rounded-lg border border-slate-200">
                      <span className="text-[10px] text-slate-400">Accuracy</span>
                      <div className="font-bold text-slate-900 font-mono">{selectedReport.model_metrics.accuracy}%</div>
                    </div>
                    <div className="bg-white p-2.5 rounded-lg border border-slate-200">
                      <span className="text-[10px] text-slate-400">F1-Score</span>
                      <div className="font-bold text-slate-900 font-mono">{selectedReport.model_metrics.f1_score}%</div>
                    </div>
                    <div className="bg-white p-2.5 rounded-lg border border-slate-200">
                      <span className="text-[10px] text-slate-400">Precision</span>
                      <div className="font-bold text-slate-900 font-mono">{selectedReport.model_metrics.precision}%</div>
                    </div>
                    <div className="bg-white p-2.5 rounded-lg border border-slate-200">
                      <span className="text-[10px] text-slate-400">Recall</span>
                      <div className="font-bold text-slate-900 font-mono">{selectedReport.model_metrics.recall}%</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* 4. Strategic Recommendations */}
              <div className="space-y-3">
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  04. Strategic Clinical Recommendations
                </h3>
                <ul className="space-y-2 text-xs text-slate-700">
                  {selectedReport.recommendations.map((rec, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                      <span>{rec}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* 5. Limitations & Future Scope */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div className="p-4 rounded-xl border border-slate-200 space-y-2">
                  <h4 className="font-bold text-slate-900">Research Limitations</h4>
                  <ul className="list-disc pl-4 space-y-1 text-slate-600">
                    {selectedReport.limitations.map((lim, i) => (
                      <li key={i}>{lim}</li>
                    ))}
                  </ul>
                </div>
                <div className="p-4 rounded-xl border border-slate-200 space-y-2">
                  <h4 className="font-bold text-slate-900">Future Scope</h4>
                  <ul className="list-disc pl-4 space-y-1 text-slate-600">
                    {selectedReport.future_scope.map((fut, i) => (
                      <li key={i}>{fut}</li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Regulatory Disclaimer */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-[11px] text-slate-500 leading-relaxed space-y-1">
                <div className="font-semibold text-slate-700">Analytical & Non-Diagnostic Disclaimer</div>
                <p>
                  HealthInsight is an educational and analytical research demonstration platform. Risk prediction scores and descriptive statistics are derived mathematically from synthetic cohort features and are not designed to substitute clinical diagnosis, physician oversight, or licensed healthcare judgment.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
