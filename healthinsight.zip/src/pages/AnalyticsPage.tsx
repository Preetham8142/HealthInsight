import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { ColumnStats, CorrelationData } from '../types';
import { useToast } from '../context/ToastContext';
import {
  BarChart3,
  TrendingUp,
  Download,
  Play,
  Loader2,
  Sliders,
  Table as TableIcon
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  LineChart,
  Line,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell,
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend
} from 'recharts';

export const AnalyticsPage: React.FC = () => {
  const [stats, setStats] = useState<Record<string, ColumnStats>>({});
  const [correlation, setCorrelation] = useState<CorrelationData | null>(null);
  const [loading, setLoading] = useState(true);

  // Custom Chart Studio State
  const [xAxis, setXAxis] = useState('diagnosis');
  const [yAxis, setYAxis] = useState('medical_expense');
  const [chartType, setChartType] = useState<'bar' | 'line' | 'area' | 'scatter' | 'pie'>('bar');
  const [customChartData, setCustomChartData] = useState<any[]>([]);
  const [chartLoading, setChartLoading] = useState(false);

  const { showToast } = useToast();

  const availableFeatures = [
    { value: 'diagnosis', label: 'Diagnosis (Categorical)' },
    { value: 'department', label: 'Department (Categorical)' },
    { value: 'gender', label: 'Gender (Categorical)' },
    { value: 'risk_level', label: 'Risk Stratification (Categorical)' },
    { value: 'age', label: 'Age (Continuous)' },
    { value: 'bmi', label: 'BMI (Continuous)' },
    { value: 'systolic_bp', label: 'Systolic BP (Continuous)' },
    { value: 'glucose_level', label: 'Glucose Level (Continuous)' },
    { value: 'cholesterol', label: 'Cholesterol (Continuous)' },
    { value: 'length_of_stay', label: 'Length of Stay (Continuous)' },
    { value: 'medical_expense', label: 'Medical Expense (Continuous)' }
  ];

  const continuousFeatures = [
    { value: 'medical_expense', label: 'Medical Expense ($)' },
    { value: 'length_of_stay', label: 'Length of Stay (Days)' },
    { value: 'age', label: 'Patient Age' },
    { value: 'bmi', label: 'Body Mass Index (BMI)' },
    { value: 'systolic_bp', label: 'Systolic BP (mmHg)' },
    { value: 'glucose_level', label: 'Glucose Level (mg/dL)' },
    { value: 'cholesterol', label: 'Cholesterol (mg/dL)' },
    { value: 'heart_rate', label: 'Heart Rate (bpm)' }
  ];

  useEffect(() => {
    async function loadData() {
      try {
        setLoading(true);
        const [sumRes, corrRes] = await Promise.all([
          api.analytics.getSummary(),
          api.analytics.getCorrelation()
        ]);
        setStats(sumRes.numeric_stats);
        setCorrelation(corrRes.correlation);
        await generateCustomChart('diagnosis', 'medical_expense', 'bar');
      } catch (err: any) {
        showToast('Failed to load exploratory analytics data.', 'error');
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, []);

  const generateCustomChart = async (x: string, y: string, type: string) => {
    setChartLoading(true);
    try {
      const res = await api.analytics.getCustomChart({
        x_axis: x,
        y_axis: y,
        chart_type: type
      });
      setCustomChartData(res.data);
    } catch (err: any) {
      showToast('Error rendering custom chart.', 'error');
    } finally {
      setChartLoading(false);
    }
  };

  const handleApplyCustomChart = (e: React.FormEvent) => {
    e.preventDefault();
    generateCustomChart(xAxis, yAxis, chartType);
  };

  const handleExportChart = () => {
    window.print();
  };

  const PIE_COLORS = ['#0d9488', '#0284c7', '#6366f1', '#8b5cf6', '#ec4899', '#f59e0b', '#10b981', '#64748b'];

  if (loading) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center gap-3">
        <Loader2 className="w-8 h-8 text-teal-600 animate-spin" />
        <p className="text-xs font-medium text-slate-500">Computing clinical summary statistics & correlation matrix...</p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
          Exploratory Data Analysis (EDA)
        </h1>
        <p className="text-xs text-slate-500">
          Descriptive statistics, Pearson correlation matrix, and parametric visual exploration.
        </p>
      </div>

      {/* Descriptive Statistics Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden space-y-3 p-5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <TableIcon className="w-4 h-4 text-teal-600" />
            <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Parametric Summary Statistics
            </h2>
          </div>
          <span className="text-[11px] text-slate-500">N = 1,200 Observations</span>
        </div>

        <div className="overflow-x-auto border border-slate-200 rounded-lg">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 font-semibold text-slate-700">
                <th className="py-2.5 px-3">Biomarker / Feature</th>
                <th className="py-2.5 px-3 text-right">Count</th>
                <th className="py-2.5 px-3 text-right">Mean</th>
                <th className="py-2.5 px-3 text-right">Median</th>
                <th className="py-2.5 px-3 text-right">Std Dev</th>
                <th className="py-2.5 px-3 text-right">Min</th>
                <th className="py-2.5 px-3 text-right">Q1 (25%)</th>
                <th className="py-2.5 px-3 text-right">Q3 (75%)</th>
                <th className="py-2.5 px-3 text-right">Max</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono text-[11px] tabular-nums">
              {Object.values(stats).map(s => (
                <tr key={s.column} className="hover:bg-slate-50/70">
                  <td className="py-2.5 px-3 font-sans font-semibold text-slate-800">
                    {s.column.replace(/_/g, ' ').toUpperCase()}
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-600">{s.count}</td>
                  <td className="py-2.5 px-3 text-right font-medium text-slate-900">{s.mean}</td>
                  <td className="py-2.5 px-3 text-right text-slate-700">{s.median}</td>
                  <td className="py-2.5 px-3 text-right text-slate-600">{s.std}</td>
                  <td className="py-2.5 px-3 text-right text-slate-500">{s.min}</td>
                  <td className="py-2.5 px-3 text-right text-slate-600">{s.q1}</td>
                  <td className="py-2.5 px-3 text-right text-slate-600">{s.q3}</td>
                  <td className="py-2.5 px-3 text-right text-slate-500">{s.max}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Pearson Correlation Heatmap / Matrix */}
      {correlation && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-teal-600" />
              <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Pearson Correlation Coefficient Matrix (r)
              </h2>
            </div>
            <div className="flex items-center gap-4 text-[10px] text-slate-500">
              <span className="flex items-center gap-1">
                <span className="w-2.5 h-2.5 rounded bg-teal-600 inline-block" /> Strong Positive (+0.5 to +1.0)
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2.5 h-2.5 rounded bg-slate-200 inline-block" /> Neutral (0.0)
              </span>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-center text-[10px] border-collapse">
              <thead>
                <tr>
                  <th className="py-2 px-2 text-left font-semibold text-slate-700"></th>
                  {correlation.features.map(f => (
                    <th key={f} className="py-2 px-2 font-semibold text-slate-700 whitespace-nowrap">
                      {f}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {correlation.features.map(rowF => (
                  <tr key={rowF}>
                    <td className="py-2 px-2 text-left font-semibold text-slate-800 whitespace-nowrap">
                      {rowF}
                    </td>
                    {correlation.features.map(colF => {
                      const item = correlation.matrix.find(m => m.x === rowF && m.y === colF);
                      const r = item ? item.correlation : 0;
                      const absR = Math.abs(r);
                      const isSelf = rowF === colF;

                      let bgColor = 'bg-white';
                      let textColor = 'text-slate-700';

                      if (isSelf) {
                        bgColor = 'bg-teal-50 text-teal-800 font-bold';
                      } else if (r > 0.45) {
                        bgColor = 'bg-teal-100 text-teal-900 font-bold';
                      } else if (r > 0.25) {
                        bgColor = 'bg-teal-50/70 text-teal-800';
                      } else if (r < -0.25) {
                        bgColor = 'bg-rose-50 text-rose-800';
                      }

                      return (
                        <td key={colF} className={`py-2 px-2 font-mono tabular-nums ${bgColor} ${textColor}`}>
                          {r.toFixed(2)}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Interactive Custom Chart Studio */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-5 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-teal-600" />
            <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Interactive Visualization Studio
            </h2>
          </div>
          <button
            onClick={handleExportChart}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Print / Export Chart</span>
          </button>
        </div>

        {/* Studio Controls Form */}
        <form onSubmit={handleApplyCustomChart} className="grid grid-cols-1 sm:grid-cols-4 gap-4 bg-slate-50 p-4 rounded-xl text-xs">
          <div>
            <label className="block font-semibold text-slate-700 mb-1">X-Axis Feature</label>
            <select
              value={xAxis}
              onChange={e => setXAxis(e.target.value)}
              className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white"
            >
              {availableFeatures.map(f => (
                <option key={f.value} value={f.value}>{f.label}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Y-Axis Metric</label>
            <select
              value={yAxis}
              onChange={e => setYAxis(e.target.value)}
              className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white"
            >
              {continuousFeatures.map(f => (
                <option key={f.value} value={f.value}>{f.label}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Chart Type</label>
            <select
              value={chartType}
              onChange={e => setChartType(e.target.value as any)}
              className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white"
            >
              <option value="bar">Bar Chart (Categorical)</option>
              <option value="line">Line Chart (Trend)</option>
              <option value="area">Area Chart (Filled Curve)</option>
              <option value="scatter">Scatter Plot (Correlation)</option>
              <option value="pie">Pie Chart (Proportion)</option>
            </select>
          </div>

          <div className="flex items-end">
            <button
              type="submit"
              disabled={chartLoading}
              className="w-full py-2 px-3 text-xs font-semibold text-white bg-teal-600 hover:bg-teal-700 disabled:opacity-60 rounded-lg flex items-center justify-center gap-1.5 shadow-xs"
            >
              {chartLoading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5" />}
              <span>Render Chart</span>
            </button>
          </div>
        </form>

        {/* Dynamic Chart Display Container */}
        <div className="h-80 w-full pt-2">
          {chartLoading ? (
            <div className="h-full flex items-center justify-center text-slate-400">
              <Loader2 className="w-6 h-6 animate-spin text-teal-600" />
            </div>
          ) : customChartData.length === 0 ? (
            <div className="h-full flex items-center justify-center text-xs text-slate-400">
              Select parameters and click Render Chart.
            </div>
          ) : chartType === 'bar' ? (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={customChartData} margin={{ top: 10, right: 10, left: 10, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="name" tick={{ fontSize: 10 }} angle={-25} textAnchor="end" interval={0} />
                <YAxis tick={{ fontSize: 10 }} />
                <Tooltip contentStyle={{ fontSize: '11px', borderRadius: '8px' }} />
                <Bar dataKey="value" fill="#0d9488" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : chartType === 'line' ? (
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={customChartData} margin={{ top: 10, right: 10, left: 10, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="name" tick={{ fontSize: 10 }} angle={-25} textAnchor="end" interval={0} />
                <YAxis tick={{ fontSize: 10 }} />
                <Tooltip contentStyle={{ fontSize: '11px', borderRadius: '8px' }} />
                <Line type="monotone" dataKey="value" stroke="#0284c7" strokeWidth={2} dot={{ r: 3 }} />
              </LineChart>
            </ResponsiveContainer>
          ) : chartType === 'area' ? (
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={customChartData} margin={{ top: 10, right: 10, left: 10, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="name" tick={{ fontSize: 10 }} angle={-25} textAnchor="end" interval={0} />
                <YAxis tick={{ fontSize: 10 }} />
                <Tooltip contentStyle={{ fontSize: '11px', borderRadius: '8px' }} />
                <Area type="monotone" dataKey="value" stroke="#6366f1" fill="#e0e7ff" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          ) : chartType === 'pie' ? (
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={customChartData}
                  cx="50%"
                  cy="50%"
                  outerRadius={100}
                  dataKey="value"
                  label={({ name }: any) => name}
                >
                  {customChartData.map((_, index) => (
                    <Cell key={`cell-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ fontSize: '11px', borderRadius: '8px' }} />
                <Legend wrapperStyle={{ fontSize: '11px' }} />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <ScatterChart margin={{ top: 10, right: 20, left: 10, bottom: 10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="x" tick={{ fontSize: 10 }} />
                <YAxis dataKey="y" tick={{ fontSize: 10 }} />
                <Tooltip contentStyle={{ fontSize: '11px', borderRadius: '8px' }} />
                <Scatter name="Observation" data={customChartData} fill="#0d9488" />
              </ScatterChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>
    </div>
  );
};
