import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Activity,
  ArrowRight,
  Database,
  BrainCircuit,
  FileSpreadsheet,
  FileCheck,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  GraduationCap
} from 'lucide-react';
import heroImg from '../assets/images/hero_healthcare_analytics_1790764059606.jpg';
import riskImg from '../assets/images/feature_risk_prediction_1790764094293.jpg';
import dataImg from '../assets/images/feature_data_pipeline_1790764111358.jpg';

export const LandingPage: React.FC = () => {
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const faqs = [
    {
      q: 'What is HealthInsight and who is it designed for?',
      a: 'HealthInsight is an end-to-end healthcare data analytics and clinical risk prediction web platform. Built as a comprehensive Healthcare Data Analytics Internship project, it provides healthcare practitioners, clinical researchers, and data analysts with exploratory statistical analysis, data cleaning pipelines, and predictive risk modeling.'
    },
    {
      q: 'How does the Patient Risk Prediction model work?',
      a: 'The machine learning engine uses Scikit-learn algorithms (Random Forest, Decision Tree, Logistic Regression) trained on clinical indicators including age, BMI, systolic and diastolic blood pressure, glucose, and cholesterol. It generates stratified risk ratings (Low, Moderate, High) along with contributing risk factor weights.'
    },
    {
      q: 'Does this platform replace clinical medical diagnosis?',
      a: 'No. HealthInsight is strictly an educational, research, and data analytics decision-support tool. It clearly presents an explicit disclaimer and should never be used as a standalone clinical diagnosis.'
    },
    {
      q: 'Can I upload custom patient datasets and clean them?',
      a: 'Yes. The dataset ingestion pipeline accepts CSV files, inspects data schemas, detects missing values and duplicate rows, and provides automated preprocessing strategies (median imputation, IQR outlier clipping, categorical encoding, and min-max normalization) with immediate before/after reporting.'
    },
    {
      q: 'What backend architecture powers the analytics calculations?',
      a: 'The system features a dual architecture: a live Node.js/Express full-stack engine with JSON/SQLite persistence for seamless instant interaction, alongside a complete Python FastAPI + SQLAlchemy + Scikit-learn backend codebase ready for local or cloud PostgreSQL deployment.'
    }
  ];

  return (
    <div className="space-y-20 pb-16">
      {/* Hero Section */}
      <section className="relative pt-6 pb-12 sm:pt-12 sm:pb-20">
        <div className="max-w-4xl mx-auto text-center space-y-6">
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-teal-800 bg-teal-50/90 border border-teal-200/80 px-3.5 py-1.5 rounded-full">
            <Activity className="w-3.5 h-3.5 text-teal-600" />
            <span>Healthcare Data Analytics & Machine Learning Platform</span>
          </div>

          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-slate-900 tracking-tight leading-[1.15] text-balance">
            Turn Healthcare Data Into Actionable Insights
          </h1>

          <p className="text-lg sm:text-xl text-slate-600 max-w-2xl mx-auto leading-relaxed">
            Analyze patient data, discover healthcare trends and explore data-driven risk insights with an interactive analytics platform.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-4 pt-4">
            <Link
              to="/register"
              className="inline-flex items-center gap-2 px-6 py-3 text-sm font-semibold text-white bg-teal-600 hover:bg-teal-700 rounded-xl shadow-xs transition-colors"
            >
              Get Started Free
              <ArrowRight className="w-4 h-4" />
            </Link>
            <Link
              to="/dashboard"
              className="inline-flex items-center gap-2 px-6 py-3 text-sm font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl shadow-xs transition-colors"
            >
              Explore Live Analytics
            </Link>
          </div>

          {/* Proof Adjacency Banner */}
          <div className="flex items-center justify-center gap-6 pt-4 text-xs text-slate-500 font-medium">
            <span>1,200+ Synthetic Cohort Records</span>
            <span>·</span>
            <span>Real Scikit-learn ML Pipeline</span>
            <span>·</span>
            <span>Zero Mock Calculations</span>
          </div>
        </div>

        {/* Hero Image Showcase */}
        <div className="mt-12 max-w-5xl mx-auto rounded-2xl overflow-hidden border border-slate-200 shadow-md bg-white">
          <img
            src={heroImg}
            alt="HealthInsight Clinical Analytics Interface"
            className="w-full h-auto object-cover max-h-[520px]"
            loading="eager"
            referrerPolicy="no-referrer"
          />
        </div>
      </section>

      {/* Why HealthInsight? */}
      <section className="max-w-5xl mx-auto space-y-8">
        <div className="text-center space-y-3">
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
            Why HealthInsight?
          </h2>
          <p className="text-sm sm:text-base text-slate-600 max-w-2xl mx-auto">
            Bridging raw electronic medical records and actionable clinical intelligence through transparent statistical methodologies and machine learning.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-2xs space-y-3">
            <div className="w-10 h-10 rounded-lg bg-teal-50 text-teal-700 flex items-center justify-center">
              <Database className="w-5 h-5" />
            </div>
            <h3 className="text-base font-semibold text-slate-900">End-to-End Pipeline</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              From dirty CSV ingestion and missing value imputation to statistical EDA and clinical PDF reporting in one coherent interface.
            </p>
          </div>

          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-2xs space-y-3">
            <div className="w-10 h-10 rounded-lg bg-teal-50 text-teal-700 flex items-center justify-center">
              <BrainCircuit className="w-5 h-5" />
            </div>
            <h3 className="text-base font-semibold text-slate-900">Explainable ML Models</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Trains Logistic Regression, Decision Trees, and Random Forests with full accuracy, recall, F1 metrics, and transparent factor weights.
            </p>
          </div>

          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-2xs space-y-3">
            <div className="w-10 h-10 rounded-lg bg-teal-50 text-teal-700 flex items-center justify-center">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <h3 className="text-base font-semibold text-slate-900">Rigorous Preprocessing</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Automated IQR outlier clipping, median imputation, and min-max scaling with comparative before/after data quality summaries.
            </p>
          </div>
        </div>
      </section>

      {/* Key Features Bento Showcase */}
      <section className="max-w-6xl mx-auto space-y-10">
        <div className="text-center space-y-3">
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
            Key Platform Capabilities
          </h2>
          <p className="text-sm sm:text-base text-slate-600 max-w-2xl mx-auto">
            Built specifically to solve common data fragmentation and analytical friction in modern health systems.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
          <div className="space-y-5">
            <div className="text-xs font-bold text-teal-700 uppercase tracking-wider">
              01. Ingestion & Quality Control
            </div>
            <h3 className="text-2xl font-bold text-slate-900 tracking-tight">
              Intelligent Healthcare Data Cleaning Pipeline
            </h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              Raw patient datasets are notoriously plagued by missing values, measurement artifacts, and inconsistent formatting. HealthInsight inspects column types, detects numerical anomalies via Interquartile Range (IQR), and preserves epidemiological validity.
            </p>
            <ul className="space-y-2.5 text-xs text-slate-700 font-medium">
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0" />
                <span>Automated missing value handling (median, mean, mode, listwise drop)</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0" />
                <span>Interquartile Range outlier clipping [Q1 - 1.5×IQR, Q3 + 1.5×IQR]</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0" />
                <span>Exportable clean CSV with verifiable before/after data variance logs</span>
              </li>
            </ul>
          </div>
          <div className="rounded-2xl overflow-hidden border border-slate-200 shadow-sm bg-white">
            <img
              src={dataImg}
              alt="Data Pipeline Concept"
              className="w-full h-80 object-cover"
              loading="lazy"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center pt-8">
          <div className="order-2 lg:order-1 rounded-2xl overflow-hidden border border-slate-200 shadow-sm bg-white">
            <img
              src={riskImg}
              alt="Risk Prediction Engine"
              className="w-full h-80 object-cover"
              loading="lazy"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="order-1 lg:order-2 space-y-5">
            <div className="text-xs font-bold text-teal-700 uppercase tracking-wider">
              02. Predictive Machine Learning
            </div>
            <h3 className="text-2xl font-bold text-slate-900 tracking-tight">
              Multivariate Patient Risk Stratification
            </h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              Harness classification models to detect patients at elevated probability of readmission or acute deterioration. Gain quantitative visibility into which biomarkers contribute most heavily to each patient risk category.
            </p>
            <ul className="space-y-2.5 text-xs text-slate-700 font-medium">
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0" />
                <span>Evaluates blood pressure, BMI, glucose, cholesterol, and age</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0" />
                <span>Confusion matrix and 80/20 train/test split verification</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0" />
                <span>Clear clinical non-diagnostic disclaimer on every prediction</span>
              </li>
            </ul>
          </div>
        </div>
      </section>

      {/* Technology Stack Grid */}
      <section className="max-w-5xl mx-auto bg-slate-900 text-white rounded-2xl p-8 sm:p-12 space-y-8">
        <div className="text-center space-y-3">
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight">
            Production Technology Architecture
          </h2>
          <p className="text-sm text-slate-300 max-w-xl mx-auto">
            Architected according to enterprise software principles with clean boundaries between presentation, business logic, and predictive modeling.
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700 text-center space-y-1">
            <div className="text-sm font-bold text-teal-400">React + Vite</div>
            <div className="text-[11px] text-slate-400">TypeScript SPA & Hooks</div>
          </div>
          <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700 text-center space-y-1">
            <div className="text-sm font-bold text-teal-400">Python / FastAPI</div>
            <div className="text-[11px] text-slate-400">REST API & SQLAlchemy</div>
          </div>
          <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700 text-center space-y-1">
            <div className="text-sm font-bold text-teal-400">Scikit-learn</div>
            <div className="text-[11px] text-slate-400">Classifiers & Metrics</div>
          </div>
          <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700 text-center space-y-1">
            <div className="text-sm font-bold text-teal-400">PostgreSQL / SQLite</div>
            <div className="text-[11px] text-slate-400">Relational Persistence</div>
          </div>
        </div>
      </section>

      {/* Internship Project Banner */}
      <section className="max-w-4xl mx-auto bg-white border border-teal-200 rounded-2xl p-8 sm:p-10 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-6">
        <div className="space-y-2 text-center sm:text-left">
          <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-teal-700">
            <GraduationCap className="w-4 h-4" />
            <span>Healthcare Data Analytics Internship Project</span>
          </div>
          <h3 className="text-xl font-bold text-slate-900">
            6-Week Structured Internship Curriculum
          </h3>
          <p className="text-xs text-slate-600 max-w-lg">
            Review the complete problem statement, methodology, data collection, 6-week milestone breakdown, limitations, and future research scope.
          </p>
        </div>
        <Link
          to="/project"
          className="px-5 py-2.5 text-xs font-semibold text-white bg-teal-600 hover:bg-teal-700 rounded-lg shadow-xs whitespace-nowrap"
        >
          View Project Dossier
        </Link>
      </section>

      {/* FAQ Accordion */}
      <section className="max-w-3xl mx-auto space-y-6">
        <div className="text-center space-y-2">
          <h2 className="text-2xl font-bold text-slate-900">Frequently Asked Questions</h2>
          <p className="text-xs text-slate-600">Everything you need to know about the platform and its analytical algorithms.</p>
        </div>

        <div className="space-y-3">
          {faqs.map((faq, idx) => {
            const isOpen = openFaq === idx;
            return (
              <div
                key={idx}
                className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-2xs"
              >
                <button
                  onClick={() => setOpenFaq(isOpen ? null : idx)}
                  className="w-full p-4 text-left flex items-center justify-between gap-4 font-semibold text-sm text-slate-900 hover:text-teal-700 transition-colors"
                >
                  <span>{faq.q}</span>
                  {isOpen ? <ChevronUp className="w-4 h-4 shrink-0 text-slate-400" /> : <ChevronDown className="w-4 h-4 shrink-0 text-slate-400" />}
                </button>
                {isOpen && (
                  <div className="px-4 pb-4 text-xs text-slate-600 leading-relaxed border-t border-slate-100 pt-3">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

      {/* Footer */}
      <footer className="max-w-7xl mx-auto pt-12 border-t border-slate-200 text-xs text-slate-500 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          © 2026 HealthInsight Platform. Healthcare Data Analytics Internship Project.
        </div>
        <div className="flex items-center gap-6">
          <Link to="/project" className="hover:text-slate-900">Internship Project</Link>
          <Link to="/reports" className="hover:text-slate-900">Reports</Link>
          <Link to="/login" className="hover:text-slate-900">Sign In</Link>
        </div>
      </footer>
    </div>
  );
};
