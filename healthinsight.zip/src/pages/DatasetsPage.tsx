import React, { useState, useEffect, useRef } from 'react';
import { api } from '../services/api';
import { DatasetMeta, CleaningReport } from '../types';
import { useToast } from '../context/ToastContext';
import {
  UploadCloud,
  FileSpreadsheet,
  Download,
  Trash2,
  Sparkles,
  AlertCircle,
  CheckCircle2,
  Table,
  ArrowRight,
  Loader2,
  X
} from 'lucide-react';

export const DatasetsPage: React.FC = () => {
  const [datasets, setDatasets] = useState<DatasetMeta[]>([]);
  const [selectedDataset, setSelectedDataset] = useState<DatasetMeta | null>(null);
  const [previewData, setPreviewData] = useState<{ headers: string[]; preview: Record<string, any>[] } | null>(null);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [dragActive, setDragActive] = useState(false);

  // Cleaning pipeline state
  const [cleanModalOpen, setCleanModalOpen] = useState(false);
  const [cleaning, setCleaning] = useState(false);
  const [cleaningReport, setCleaningReport] = useState<CleaningReport | null>(null);
  const [cleanOptions, setCleanOptions] = useState({
    missing_strategy: 'median',
    remove_duplicates: true,
    handle_outliers: true,
    scaling: 'none'
  });

  const fileInputRef = useRef<HTMLInputElement>(null);
  const { showToast } = useToast();

  const fetchDatasets = async () => {
    try {
      setLoading(true);
      const res = await api.datasets.getAll();
      setDatasets(res.datasets);
      if (res.datasets.length > 0 && !selectedDataset) {
        setSelectedDataset(res.datasets[0]);
        loadPreview(res.datasets[0].id);
      }
    } catch (err: any) {
      showToast('Failed to load datasets list.', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDatasets();
  }, []);

  const loadPreview = async (datasetId: string) => {
    try {
      const res = await api.datasets.getPreview(datasetId);
      setPreviewData({ headers: res.headers, preview: res.preview });
    } catch (err: any) {
      showToast('Failed to generate dataset preview.', 'error');
    }
  };

  const handleSelectDataset = (ds: DatasetMeta) => {
    setSelectedDataset(ds);
    setCleaningReport(null);
    loadPreview(ds.id);
  };

  const handleFileProcess = async (file: File) => {
    if (!file.name.endsWith('.csv') && file.type !== 'text/csv' && file.type !== 'application/vnd.ms-excel') {
      showToast('Please upload a valid CSV formatted file (.csv).', 'error');
      return;
    }

    if (file.size > 25 * 1024 * 1024) {
      showToast('File size exceeds the 25MB maximum upload limit.', 'error');
      return;
    }

    setUploading(true);
    try {
      const res = await api.datasets.upload(file);
      showToast(`Dataset "${res.dataset.name}" ingested successfully!`, 'success');
      await fetchDatasets();
      setSelectedDataset(res.dataset);
      loadPreview(res.dataset.id);
    } catch (err: any) {
      showToast(err.message || 'Dataset upload failed.', 'error');
    } finally {
      setUploading(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileProcess(e.dataTransfer.files[0]);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
  };

  const handleCleanPipeline = async () => {
    if (!selectedDataset) return;
    setCleaning(true);
    try {
      const res = await api.datasets.clean(selectedDataset.id, cleanOptions);
      setCleaningReport(res.report);
      showToast('Data cleaning pipeline completed successfully!', 'success');
      setCleanModalOpen(false);
      await fetchDatasets();
      // Reload preview for cleaned dataset
      loadPreview(selectedDataset.id);
    } catch (err: any) {
      showToast(err.message || 'Data cleaning pipeline failed.', 'error');
    } finally {
      setCleaning(false);
    }
  };

  const handleDelete = async (id: string, isSample?: boolean) => {
    if (isSample) {
      showToast('The primary sample dataset is protected and cannot be deleted.', 'error');
      return;
    }
    if (!window.confirm('Are you sure you want to delete this dataset?')) return;

    try {
      await api.datasets.delete(id);
      showToast('Dataset deleted successfully.', 'success');
      setSelectedDataset(null);
      setPreviewData(null);
      fetchDatasets();
    } catch (err: any) {
      showToast(err.message || 'Failed to delete dataset.', 'error');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            Healthcare Datasets & Preprocessing Pipeline
          </h1>
          <p className="text-xs text-slate-500">
            Upload CSV patient files, inspect data quality schemas, and execute cleaning pipelines.
          </p>
        </div>

        {selectedDataset && (
          <div className="flex items-center gap-2.5">
            <button
              onClick={() => setCleanModalOpen(true)}
              className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-teal-600 hover:bg-teal-700 rounded-lg shadow-xs transition-colors"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Clean & Preprocess</span>
            </button>
            <a
              href={api.datasets.getDownloadUrl(selectedDataset.id)}
              className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg shadow-2xs transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download CSV</span>
            </a>
          </div>
        )}
      </div>

      {/* Drag & Drop Upload Zone */}
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
        className={`border-2 border-dashed rounded-2xl p-8 text-center transition-all cursor-pointer bg-white ${
          dragActive
            ? 'border-teal-500 bg-teal-50/50'
            : 'border-slate-200 hover:border-teal-400 hover:bg-slate-50/60'
        }`}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept=".csv"
          className="hidden"
          onChange={e => {
            if (e.target.files && e.target.files[0]) {
              handleFileProcess(e.target.files[0]);
            }
          }}
        />
        <div className="max-w-md mx-auto space-y-3">
          <div className="w-12 h-12 rounded-xl bg-teal-50 text-teal-600 mx-auto flex items-center justify-center">
            {uploading ? <Loader2 className="w-6 h-6 animate-spin" /> : <UploadCloud className="w-6 h-6" />}
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900">
              {uploading ? 'Parsing and analyzing CSV structure...' : 'Drop your healthcare CSV dataset here'}
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Supports CSV files up to 25MB with automated schema & missing value detection.
            </p>
          </div>
          <button
            type="button"
            className="px-4 py-1.5 text-xs font-semibold text-teal-700 bg-teal-50 border border-teal-200 rounded-lg hover:bg-teal-100 transition-colors pointer-events-none"
          >
            Browse Local File
          </button>
        </div>
      </div>

      {/* Datasets Management Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Datasets List */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-4">
          <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
            Available Datasets ({datasets.length})
          </h2>

          <div className="space-y-2">
            {datasets.map(ds => {
              const isSelected = selectedDataset?.id === ds.id;
              return (
                <div
                  key={ds.id}
                  onClick={() => handleSelectDataset(ds)}
                  className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                    isSelected
                      ? 'border-teal-500 bg-teal-50/40 shadow-xs'
                      : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="space-y-1 min-w-0">
                      <div className="flex items-center gap-1.5">
                        <FileSpreadsheet className="w-4 h-4 text-teal-600 shrink-0" />
                        <span className="font-semibold text-xs text-slate-900 truncate">
                          {ds.name}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-500 tabular-nums">
                        {ds.row_count.toLocaleString()} rows · {ds.col_count} columns · {ds.missing_values} missing
                      </div>
                      <div className="flex items-center gap-2 pt-1 text-[10px]">
                        <span className={`font-semibold ${ds.status === 'Cleaned' ? 'text-emerald-600' : 'text-amber-600'}`}>
                          Status: {ds.status}
                        </span>
                        {ds.is_sample && (
                          <span className="text-slate-400">· Synthetic Cohort</span>
                        )}
                      </div>
                    </div>

                    {!ds.is_sample && (
                      <button
                        onClick={e => {
                          e.stopPropagation();
                          handleDelete(ds.id, ds.is_sample);
                        }}
                        className="text-slate-400 hover:text-rose-600 p-1 rounded"
                        title="Delete dataset"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Selected Dataset Analysis & Preview */}
        <div className="lg:col-span-2 space-y-6">
          {selectedDataset && (
            <>
              {/* Dataset Statistics Card */}
              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-4">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <div>
                    <h2 className="text-sm font-bold text-slate-900">{selectedDataset.name}</h2>
                    <p className="text-xs text-slate-500 font-mono">{selectedDataset.filename}</p>
                  </div>
                  {selectedDataset.status === 'Cleaned' ? (
                    <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-200">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Preprocessed & Cleaned</span>
                    </div>
                  ) : (
                    <div className="flex items-center gap-1.5 text-xs font-semibold text-amber-700 bg-amber-50 px-2.5 py-1 rounded-md border border-amber-200">
                      <AlertCircle className="w-3.5 h-3.5" />
                      <span>Raw Ingestion State</span>
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div className="bg-slate-50 p-3 rounded-lg border border-slate-100">
                    <span className="text-[11px] text-slate-400">Total Observations</span>
                    <div className="text-lg font-bold text-slate-900 tabular-nums">
                      {selectedDataset.row_count.toLocaleString()}
                    </div>
                  </div>
                  <div className="bg-slate-50 p-3 rounded-lg border border-slate-100">
                    <span className="text-[11px] text-slate-400">Features / Columns</span>
                    <div className="text-lg font-bold text-slate-900 tabular-nums">
                      {selectedDataset.col_count}
                    </div>
                  </div>
                  <div className="bg-slate-50 p-3 rounded-lg border border-slate-100">
                    <span className="text-[11px] text-slate-400">Missing Values</span>
                    <div className={`text-lg font-bold tabular-nums ${selectedDataset.missing_values > 0 ? 'text-amber-600' : 'text-emerald-600'}`}>
                      {selectedDataset.missing_values}
                    </div>
                  </div>
                  <div className="bg-slate-50 p-3 rounded-lg border border-slate-100">
                    <span className="text-[11px] text-slate-400">Duplicate Rows</span>
                    <div className="text-lg font-bold text-slate-900 tabular-nums">
                      {selectedDataset.duplicates}
                    </div>
                  </div>
                </div>

                <div className="space-y-2 pt-1 text-xs">
                  <div>
                    <span className="font-semibold text-slate-700">Numerical Columns: </span>
                    <span className="text-slate-500 font-mono text-[11px]">
                      {selectedDataset.numeric_cols?.join(', ') || 'None detected'}
                    </span>
                  </div>
                  <div>
                    <span className="font-semibold text-slate-700">Categorical Columns: </span>
                    <span className="text-slate-500 font-mono text-[11px]">
                      {selectedDataset.categorical_cols?.join(', ') || 'None detected'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Cleaning Comparative Report (if just cleaned) */}
              {cleaningReport && (
                <div className="bg-white p-5 rounded-xl border border-emerald-200 shadow-2xs space-y-4">
                  <div className="flex items-center gap-2 text-xs font-bold text-emerald-800">
                    <Sparkles className="w-4 h-4 text-emerald-600" />
                    <span>Data Cleaning Comparative Summary</span>
                  </div>

                  <div className="grid grid-cols-2 gap-4 text-xs">
                    <div className="bg-rose-50/60 p-3.5 rounded-lg border border-rose-200 space-y-1">
                      <div className="font-bold text-rose-900">Before Preprocessing</div>
                      <div className="text-rose-700">Rows: {cleaningReport.before.rows}</div>
                      <div className="text-rose-700">Missing Values: {cleaningReport.before.missing_values}</div>
                      <div className="text-rose-700">Duplicates: {cleaningReport.before.duplicates}</div>
                    </div>
                    <div className="bg-emerald-50/60 p-3.5 rounded-lg border border-emerald-200 space-y-1">
                      <div className="font-bold text-emerald-900">After Pipeline Execution</div>
                      <div className="text-emerald-700">Rows: {cleaningReport.after.rows}</div>
                      <div className="text-emerald-700">Missing Values: {cleaningReport.after.missing_values} (Resolved)</div>
                      <div className="text-emerald-700">Outliers Clipped (IQR): {cleaningReport.outliers_handled}</div>
                    </div>
                  </div>
                </div>
              )}

              {/* First 20 Rows Preview Table */}
              <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden space-y-3 p-5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Table className="w-4 h-4 text-teal-600" />
                    <h3 className="text-xs font-bold text-slate-900">
                      Dataset Preview (First 20 Observations)
                    </h3>
                  </div>
                  <span className="text-[11px] text-slate-500 font-mono">
                    {previewData?.preview.length || 0} rows displayed
                  </span>
                </div>

                <div className="overflow-x-auto max-h-96 border border-slate-200 rounded-lg">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead className="sticky top-0 bg-slate-100 border-b border-slate-200">
                      <tr>
                        {previewData?.headers.map(h => (
                          <th key={h} className="py-2.5 px-3 font-semibold text-slate-700 whitespace-nowrap">
                            {h}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {previewData?.preview.map((row, idx) => (
                        <tr key={idx} className="hover:bg-slate-50">
                          {previewData.headers.map(h => (
                            <td key={h} className="py-2 px-3 text-slate-600 whitespace-nowrap font-mono text-[11px]">
                              {String(row[h] ?? '')}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          )}
        </div>
      </div>

      {/* Data Cleaning Pipeline Configuration Modal */}
      {cleanModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xl max-w-lg w-full p-6 space-y-5">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-teal-600" />
                <h3 className="text-sm font-bold text-slate-900">Configure Data Cleaning Pipeline</h3>
              </div>
              <button onClick={() => setCleanModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  1. Missing Value Strategy
                </label>
                <select
                  value={cleanOptions.missing_strategy}
                  onChange={e => setCleanOptions({ ...cleanOptions, missing_strategy: e.target.value as any })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white"
                >
                  <option value="median">Impute with Median (Recommended for skewed vitals)</option>
                  <option value="mean">Impute with Mean (Standard average)</option>
                  <option value="drop">Drop Rows with Missing Values</option>
                  <option value="mode">Impute with Mode (Most frequent)</option>
                </select>
              </div>

              <div>
                <label className="flex items-center gap-2 cursor-pointer font-medium text-slate-700">
                  <input
                    type="checkbox"
                    checked={cleanOptions.remove_duplicates}
                    onChange={e => setCleanOptions({ ...cleanOptions, remove_duplicates: e.target.checked })}
                    className="w-4 h-4 text-teal-600 rounded border-slate-300 focus:ring-teal-500"
                  />
                  <span>2. Deduplicate: Remove exact duplicate rows</span>
                </label>
              </div>

              <div>
                <label className="flex items-center gap-2 cursor-pointer font-medium text-slate-700">
                  <input
                    type="checkbox"
                    checked={cleanOptions.handle_outliers}
                    onChange={e => setCleanOptions({ ...cleanOptions, handle_outliers: e.target.checked })}
                    className="w-4 h-4 text-teal-600 rounded border-slate-300 focus:ring-teal-500"
                  />
                  <span>3. Outlier Handling: Clip extreme values using 1.5×IQR boundary</span>
                </label>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  4. Numerical Feature Scaling
                </label>
                <select
                  value={cleanOptions.scaling}
                  onChange={e => setCleanOptions({ ...cleanOptions, scaling: e.target.value as any })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white"
                >
                  <option value="none">None (Keep original clinical units: mmHg, mg/dL)</option>
                  <option value="min-max">Min-Max Normalization [0.0, 1.0]</option>
                </select>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setCleanModalOpen(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-lg"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleCleanPipeline}
                disabled={cleaning}
                className="px-4 py-2 text-xs font-semibold text-white bg-teal-600 hover:bg-teal-700 disabled:opacity-60 rounded-lg flex items-center gap-1.5"
              >
                {cleaning && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                <span>{cleaning ? 'Executing Pipeline...' : 'Run Pipeline'}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
