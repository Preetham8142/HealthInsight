import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { PatientRecord } from '../types';
import { useToast } from '../context/ToastContext';
import {
  Search,
  Plus,
  Download,
  Trash2,
  Edit,
  Eye,
  ChevronLeft,
  ChevronRight,
  X,
  Loader2,
  User,
  HeartPulse,
  Activity,
  Calendar,
  AlertCircle
} from 'lucide-react';

export const PatientsPage: React.FC = () => {
  const [patients, setPatients] = useState<PatientRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [pagination, setPagination] = useState({ total: 0, page: 1, limit: 15, total_pages: 1 });

  // Filters & Search
  const [search, setSearch] = useState('');
  const [genderFilter, setGenderFilter] = useState('All');
  const [departmentFilter, setDepartmentFilter] = useState('All');
  const [riskFilter, setRiskFilter] = useState('All');
  const [sortBy, setSortBy] = useState('admission_date');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  // Modals state
  const [isAddEditOpen, setIsAddEditOpen] = useState(false);
  const [editingPatient, setEditingPatient] = useState<PatientRecord | null>(null);
  const [viewingPatient, setViewingPatient] = useState<PatientRecord | null>(null);
  const [deletePatientId, setDeletePatientId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  // Form State for Add / Edit
  const [formData, setFormData] = useState<Partial<PatientRecord>>({
    name: '',
    age: 45,
    gender: 'Female',
    height_cm: 168,
    weight_kg: 68,
    systolic_bp: 125,
    diastolic_bp: 82,
    heart_rate: 72,
    glucose_level: 95,
    cholesterol: 185,
    diagnosis: 'Hypertension',
    treatment: 'Standard ACE Inhibitor & Diet',
    department: 'Cardiology',
    admission_date: new Date().toISOString().split('T')[0],
    discharge_date: new Date(Date.now() + 86400000 * 3).toISOString().split('T')[0],
    length_of_stay: 3,
    medical_expense: 4200,
    risk_level: 'Low',
    readmitted: 0
  });

  const { showToast } = useToast();

  const fetchPatients = async (page = 1) => {
    try {
      setLoading(true);
      const res = await api.patients.getAll({
        search,
        gender: genderFilter !== 'All' ? genderFilter : undefined,
        department: departmentFilter !== 'All' ? departmentFilter : undefined,
        risk_level: riskFilter !== 'All' ? riskFilter : undefined,
        sort_by: sortBy,
        sort_order: sortOrder,
        page,
        limit: pagination.limit
      });
      setPatients(res.patients);
      setPagination(res.pagination);
    } catch (err: any) {
      showToast(err.message || 'Failed to retrieve patient registry.', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPatients(1);
  }, [genderFilter, departmentFilter, riskFilter, sortBy, sortOrder]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchPatients(1);
  };

  const openAddModal = () => {
    setEditingPatient(null);
    setFormData({
      name: '',
      age: 45,
      gender: 'Female',
      height_cm: 168,
      weight_kg: 68,
      systolic_bp: 125,
      diastolic_bp: 82,
      heart_rate: 72,
      glucose_level: 95,
      cholesterol: 185,
      diagnosis: 'Hypertension',
      treatment: 'Standard Care',
      department: 'Cardiology',
      admission_date: new Date().toISOString().split('T')[0],
      discharge_date: new Date(Date.now() + 86400000 * 3).toISOString().split('T')[0],
      length_of_stay: 3,
      medical_expense: 4200,
      risk_level: 'Low',
      readmitted: 0
    });
    setIsAddEditOpen(true);
  };

  const openEditModal = (p: PatientRecord) => {
    setEditingPatient(p);
    setFormData({ ...p });
    setIsAddEditOpen(true);
  };

  const handleSavePatient = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      if (editingPatient) {
        await api.patients.update(editingPatient.id, formData);
        showToast('Patient record updated successfully.', 'success');
      } else {
        await api.patients.create(formData);
        showToast('New patient registered successfully.', 'success');
      }
      setIsAddEditOpen(false);
      fetchPatients(pagination.page);
    } catch (err: any) {
      showToast(err.message || 'Failed to save patient record.', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleDeletePatient = async () => {
    if (!deletePatientId) return;
    try {
      await api.patients.delete(deletePatientId);
      showToast('Patient removed from registry.', 'success');
      setDeletePatientId(null);
      fetchPatients(pagination.page);
    } catch (err: any) {
      showToast(err.message || 'Failed to delete record.', 'error');
    }
  };

  const handleExportCSV = () => {
    window.open(api.patients.getExportUrl(), '_blank');
    showToast('Exporting clinical patient registry to CSV...', 'info');
  };

  const toggleSort = (column: string) => {
    if (sortBy === column) {
      setSortOrder(prev => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortBy(column);
      setSortOrder('asc');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header & Primary Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            Patient Cohort Management
          </h1>
          <p className="text-xs text-slate-500">
            Search, filter, inspect, and manage clinical patient encounter records.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg shadow-2xs transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={openAddModal}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-teal-600 hover:bg-teal-700 rounded-lg shadow-xs transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Add Patient</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-3">
        <form onSubmit={handleSearchSubmit} className="flex gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by patient ID, name, diagnosis, department..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:ring-1 focus:ring-teal-500"
            />
          </div>
          <button
            type="submit"
            className="px-4 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg shadow-xs transition-colors shrink-0"
          >
            Search
          </button>
        </form>

        <div className="flex flex-wrap items-center gap-3 pt-1 text-xs">
          <div className="flex items-center gap-1.5">
            <span className="text-[11px] font-semibold text-slate-500">Gender:</span>
            <select
              value={genderFilter}
              onChange={e => setGenderFilter(e.target.value)}
              className="px-2 py-1 text-xs rounded-md border border-slate-300 bg-white focus:outline-none"
            >
              <option value="All">All Genders</option>
              <option value="Male">Male</option>
              <option value="Female">Female</option>
              <option value="Other">Other</option>
            </select>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-[11px] font-semibold text-slate-500">Department:</span>
            <select
              value={departmentFilter}
              onChange={e => setDepartmentFilter(e.target.value)}
              className="px-2 py-1 text-xs rounded-md border border-slate-300 bg-white focus:outline-none"
            >
              <option value="All">All Departments</option>
              <option value="Cardiology">Cardiology</option>
              <option value="Endocrinology">Endocrinology</option>
              <option value="Pulmonology">Pulmonology</option>
              <option value="Nephrology">Nephrology</option>
              <option value="Internal Medicine">Internal Medicine</option>
              <option value="Orthopedics">Orthopedics</option>
            </select>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-[11px] font-semibold text-slate-500">Risk Level:</span>
            <select
              value={riskFilter}
              onChange={e => setRiskFilter(e.target.value)}
              className="px-2 py-1 text-xs rounded-md border border-slate-300 bg-white focus:outline-none"
            >
              <option value="All">All Risk Levels</option>
              <option value="Low">Low Risk</option>
              <option value="Moderate">Moderate Risk</option>
              <option value="High">High Risk</option>
            </select>
          </div>
        </div>
      </div>

      {/* Patient Data Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-600 font-semibold select-none">
                <th onClick={() => toggleSort('patient_id')} className="py-3 px-4 cursor-pointer hover:text-slate-900">
                  Patient ID {sortBy === 'patient_id' ? (sortOrder === 'asc' ? '↑' : '↓') : ''}
                </th>
                <th onClick={() => toggleSort('name')} className="py-3 px-4 cursor-pointer hover:text-slate-900">
                  Full Name {sortBy === 'name' ? (sortOrder === 'asc' ? '↑' : '↓') : ''}
                </th>
                <th onClick={() => toggleSort('age')} className="py-3 px-4 cursor-pointer hover:text-slate-900">
                  Age / Sex {sortBy === 'age' ? (sortOrder === 'asc' ? '↑' : '↓') : ''}
                </th>
                <th className="py-3 px-4">Vitals (BP · Gluc · BMI)</th>
                <th onClick={() => toggleSort('diagnosis')} className="py-3 px-4 cursor-pointer hover:text-slate-900">
                  Diagnosis {sortBy === 'diagnosis' ? (sortOrder === 'asc' ? '↑' : '↓') : ''}
                </th>
                <th className="py-3 px-4">Department</th>
                <th onClick={() => toggleSort('length_of_stay')} className="py-3 px-4 cursor-pointer hover:text-slate-900">
                  Stay (Days) {sortBy === 'length_of_stay' ? (sortOrder === 'asc' ? '↑' : '↓') : ''}
                </th>
                <th onClick={() => toggleSort('medical_expense')} className="py-3 px-4 cursor-pointer hover:text-slate-900">
                  Expense {sortBy === 'medical_expense' ? (sortOrder === 'asc' ? '↑' : '↓') : ''}
                </th>
                <th onClick={() => toggleSort('risk_level')} className="py-3 px-4 cursor-pointer hover:text-slate-900">
                  Risk Tier {sortBy === 'risk_level' ? (sortOrder === 'asc' ? '↑' : '↓') : ''}
                </th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <tr>
                  <td colSpan={10} className="py-12 text-center text-slate-500">
                    <Loader2 className="w-6 h-6 animate-spin mx-auto mb-2 text-teal-600" />
                    <span>Loading patient records...</span>
                  </td>
                </tr>
              ) : patients.length === 0 ? (
                <tr>
                  <td colSpan={10} className="py-12 text-center text-slate-500">
                    <AlertCircle className="w-6 h-6 mx-auto mb-2 text-slate-400" />
                    <span>No patients match the specified criteria.</span>
                  </td>
                </tr>
              ) : (
                patients.map(p => (
                  <tr key={p.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3 px-4 font-mono font-medium text-slate-900">
                      {p.patient_id}
                    </td>
                    <td className="py-3 px-4 font-semibold text-slate-900">
                      {p.name}
                    </td>
                    <td className="py-3 px-4 text-slate-600">
                      {p.age} yrs · {p.gender}
                    </td>
                    <td className="py-3 px-4 text-slate-600 font-mono text-[11px] tabular-nums">
                      {p.blood_pressure} · {p.glucose_level} mg · {p.bmi}
                    </td>
                    <td className="py-3 px-4 text-slate-800">
                      {p.diagnosis}
                    </td>
                    <td className="py-3 px-4 text-slate-600">
                      {p.department}
                    </td>
                    <td className="py-3 px-4 text-slate-600 tabular-nums">
                      {p.length_of_stay} d
                    </td>
                    <td className="py-3 px-4 text-slate-900 font-medium tabular-nums">
                      ${p.medical_expense.toLocaleString()}
                    </td>
                    <td className="py-3 px-4">
                      {p.risk_level === 'High' && (
                        <span className="text-xs font-semibold text-rose-600">High Risk</span>
                      )}
                      {p.risk_level === 'Moderate' && (
                        <span className="text-xs font-semibold text-amber-600">Moderate</span>
                      )}
                      {p.risk_level === 'Low' && (
                        <span className="text-xs font-semibold text-emerald-600">Low Risk</span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => setViewingPatient(p)}
                          className="p-1 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded"
                          title="View Details"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => openEditModal(p)}
                          className="p-1 text-slate-400 hover:text-teal-700 hover:bg-teal-50 rounded"
                          title="Edit Patient"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => setDeletePatientId(p.id)}
                          className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded"
                          title="Delete Patient"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Bar */}
        <div className="p-4 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500">
          <div>
            Showing {(pagination.page - 1) * pagination.limit + 1} to{' '}
            {Math.min(pagination.page * pagination.limit, pagination.total)} of {pagination.total} patients
          </div>
          <div className="flex items-center gap-2">
            <button
              disabled={pagination.page <= 1}
              onClick={() => fetchPatients(pagination.page - 1)}
              className="p-1.5 rounded border border-slate-200 hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="font-semibold text-slate-800">
              Page {pagination.page} of {pagination.total_pages || 1}
            </span>
            <button
              disabled={pagination.page >= pagination.total_pages}
              onClick={() => fetchPatients(pagination.page + 1)}
              className="p-1.5 rounded border border-slate-200 hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Add / Edit Patient Modal */}
      {isAddEditOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xl max-w-2xl w-full p-6 space-y-5 my-8">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h2 className="text-base font-bold text-slate-900">
                {editingPatient ? `Edit Patient (${editingPatient.patient_id})` : 'Register New Patient Encounter'}
              </h2>
              <button
                onClick={() => setIsAddEditOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSavePatient} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Full Name *</label>
                  <input
                    type="text"
                    required
                    value={formData.name || ''}
                    onChange={e => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-3 py-1.5 text-xs rounded-lg border border-slate-300 focus:outline-none focus:ring-1 focus:ring-teal-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Gender *</label>
                  <select
                    value={formData.gender || 'Female'}
                    onChange={e => setFormData({ ...formData, gender: e.target.value as any })}
                    className="w-full px-3 py-1.5 text-xs rounded-lg border border-slate-300 bg-white focus:outline-none"
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 sm:grid-cols-6 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Age</label>
                  <input
                    type="number"
                    required
                    value={formData.age || ''}
                    onChange={e => setFormData({ ...formData, age: Number(e.target.value) })}
                    className="w-full px-3 py-1.5 text-xs rounded-lg border border-slate-300 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Height (cm)</label>
                  <input
                    type="number"
                    value={formData.height_cm || ''}
                    onChange={e => setFormData({ ...formData, height_cm: Number(e.target.value) })}
                    className="w-full px-3 py-1.5 text-xs rounded-lg border border-slate-300 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Weight (kg)</label>
                  <input
                    type="number"
                    value={formData.weight_kg || ''}
                    onChange={e => setFormData({ ...formData, weight_kg: Number(e.target.value) })}
                    className="w-full px-3 py-1.5 text-xs rounded-lg border border-slate-300 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Systolic BP</label>
                  <input
                    type="number"
                    value={formData.systolic_bp || ''}
                    onChange={e => setFormData({ ...formData, systolic_bp: Number(e.target.value) })}
                    className="w-full px-3 py-1.5 text-xs rounded-lg border border-slate-300 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Diastolic BP</label>
                  <input
                    type="number"
                    value={formData.diastolic_bp || ''}
                    onChange={e => setFormData({ ...formData, diastolic_bp: Number(e.target.value) })}
                    className="w-full px-3 py-1.5 text-xs rounded-lg border border-slate-300 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Heart Rate</label>
                  <input
                    type="number"
                    value={formData.heart_rate || ''}
                    onChange={e => setFormData({ ...formData, heart_rate: Number(e.target.value) })}
                    className="w-full px-3 py-1.5 text-xs rounded-lg border border-slate-300 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Glucose (mg/dL)</label>
                  <input
                    type="number"
                    value={formData.glucose_level || ''}
                    onChange={e => setFormData({ ...formData, glucose_level: Number(e.target.value) })}
                    className="w-full px-3 py-1.5 text-xs rounded-lg border border-slate-300 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Cholesterol (mg/dL)</label>
                  <input
                    type="number"
                    value={formData.cholesterol || ''}
                    onChange={e => setFormData({ ...formData, cholesterol: Number(e.target.value) })}
                    className="w-full px-3 py-1.5 text-xs rounded-lg border border-slate-300 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Diagnosis *</label>
                  <input
                    type="text"
                    required
                    value={formData.diagnosis || ''}
                    onChange={e => setFormData({ ...formData, diagnosis: e.target.value })}
                    className="w-full px-3 py-1.5 text-xs rounded-lg border border-slate-300 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Department</label>
                  <select
                    value={formData.department || 'Internal Medicine'}
                    onChange={e => setFormData({ ...formData, department: e.target.value })}
                    className="w-full px-3 py-1.5 text-xs rounded-lg border border-slate-300 bg-white focus:outline-none"
                  >
                    <option value="Cardiology">Cardiology</option>
                    <option value="Endocrinology">Endocrinology</option>
                    <option value="Pulmonology">Pulmonology</option>
                    <option value="Nephrology">Nephrology</option>
                    <option value="Internal Medicine">Internal Medicine</option>
                    <option value="Orthopedics">Orthopedics</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Stay (Days)</label>
                  <input
                    type="number"
                    value={formData.length_of_stay || ''}
                    onChange={e => setFormData({ ...formData, length_of_stay: Number(e.target.value) })}
                    className="w-full px-3 py-1.5 text-xs rounded-lg border border-slate-300 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Medical Expense ($)</label>
                  <input
                    type="number"
                    value={formData.medical_expense || ''}
                    onChange={e => setFormData({ ...formData, medical_expense: Number(e.target.value) })}
                    className="w-full px-3 py-1.5 text-xs rounded-lg border border-slate-300 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Risk Stratification</label>
                  <select
                    value={formData.risk_level || 'Low'}
                    onChange={e => setFormData({ ...formData, risk_level: e.target.value as any })}
                    className="w-full px-3 py-1.5 text-xs rounded-lg border border-slate-300 bg-white focus:outline-none"
                  >
                    <option value="Low">Low Risk</option>
                    <option value="Moderate">Moderate Risk</option>
                    <option value="High">High Risk</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Treatment Protocol</label>
                  <input
                    type="text"
                    value={formData.treatment || ''}
                    onChange={e => setFormData({ ...formData, treatment: e.target.value })}
                    className="w-full px-3 py-1.5 text-xs rounded-lg border border-slate-300 focus:outline-none"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAddEditOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-4 py-2 text-xs font-semibold text-white bg-teal-600 hover:bg-teal-700 disabled:opacity-60 rounded-lg flex items-center gap-1.5"
                >
                  {saving && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                  <span>{editingPatient ? 'Save Changes' : 'Register Patient'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Patient Details View Drawer / Modal */}
      {viewingPatient && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xl max-w-xl w-full p-6 space-y-6">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center font-bold text-sm">
                  <User className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-base font-bold text-slate-900">{viewingPatient.name}</h2>
                  <p className="text-xs text-slate-500 font-mono">{viewingPatient.patient_id}</p>
                </div>
              </div>
              <button
                onClick={() => setViewingPatient(null)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 text-xs">
              <div className="bg-slate-50 p-3 rounded-lg border border-slate-100 space-y-0.5">
                <span className="text-[11px] text-slate-400">Demographics</span>
                <div className="font-semibold text-slate-800">{viewingPatient.age} yrs · {viewingPatient.gender}</div>
                <div className="text-[11px] text-slate-500">BMI: {viewingPatient.bmi} ({viewingPatient.height_cm}cm / {viewingPatient.weight_kg}kg)</div>
              </div>

              <div className="bg-slate-50 p-3 rounded-lg border border-slate-100 space-y-0.5">
                <span className="text-[11px] text-slate-400">Blood Pressure</span>
                <div className="font-semibold text-slate-800 font-mono">{viewingPatient.blood_pressure} mmHg</div>
                <div className="text-[11px] text-slate-500">Heart Rate: {viewingPatient.heart_rate} bpm</div>
              </div>

              <div className="bg-slate-50 p-3 rounded-lg border border-slate-100 space-y-0.5">
                <span className="text-[11px] text-slate-400">Metabolic Panel</span>
                <div className="font-semibold text-slate-800">Glucose: {viewingPatient.glucose_level} mg/dL</div>
                <div className="text-[11px] text-slate-500">Cholesterol: {viewingPatient.cholesterol} mg/dL</div>
              </div>

              <div className="bg-slate-50 p-3 rounded-lg border border-slate-100 space-y-0.5">
                <span className="text-[11px] text-slate-400">Diagnosis</span>
                <div className="font-semibold text-slate-800">{viewingPatient.diagnosis}</div>
                <div className="text-[11px] text-slate-500">Dept: {viewingPatient.department}</div>
              </div>

              <div className="bg-slate-50 p-3 rounded-lg border border-slate-100 space-y-0.5">
                <span className="text-[11px] text-slate-400">Hospital Stay</span>
                <div className="font-semibold text-slate-800">{viewingPatient.length_of_stay} Days</div>
                <div className="text-[11px] text-slate-500">{viewingPatient.admission_date} to {viewingPatient.discharge_date}</div>
              </div>

              <div className="bg-slate-50 p-3 rounded-lg border border-slate-100 space-y-0.5">
                <span className="text-[11px] text-slate-400">Financial Expense</span>
                <div className="font-semibold text-slate-800 tabular-nums">${viewingPatient.medical_expense.toLocaleString()}</div>
                <div className="text-[11px] text-slate-500">Readmission: {viewingPatient.readmitted ? 'Yes (30d)' : 'No'}</div>
              </div>
            </div>

            <div className="p-3 rounded-lg bg-teal-50 border border-teal-200 text-xs space-y-1">
              <div className="font-semibold text-teal-900">Treatment Plan</div>
              <div className="text-teal-800">{viewingPatient.treatment}</div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setViewingPatient(null)}
                className="px-4 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg"
              >
                Close Dossier
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deletePatientId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
          <div className="bg-white rounded-xl border border-slate-200 shadow-xl max-w-sm w-full p-5 space-y-4">
            <h3 className="text-sm font-bold text-slate-900">Confirm Record Removal</h3>
            <p className="text-xs text-slate-600">
              Are you sure you want to remove this patient from the active database registry? This action cannot be reversed.
            </p>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setDeletePatientId(null)}
                className="px-3.5 py-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 rounded-lg"
              >
                Cancel
              </button>
              <button
                onClick={handleDeletePatient}
                className="px-3.5 py-1.5 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-lg"
              >
                Confirm Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
