import React, { useState, useEffect, useMemo } from 'react';
import { api } from '../services/api';
import { PatientRecord, DatasetMeta } from '../types';
import {
  Users,
  Calendar,
  AlertTriangle,
  Database,
  RotateCcw,
  Loader2,
  Stethoscope,
  Building2,
  Filter
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
  AreaChart,
  Area,
  ScatterChart,
  Scatter
} from 'recharts';

export const DashboardPage: React.FC = () => {
  const [patients, setPatients] = useState<PatientRecord[]>([]);
  const [datasets, setDatasets] = useState<DatasetMeta[]>([]);
  const [loading, setLoading] = useState(true);

  // Filters state
  const [genderFilter, setGenderFilter] = useState('All');
  const [diseaseFilter, setDiseaseFilter] = useState('All');
  const [departmentFilter, setDepartmentFilter] = useState('All');
  const [riskFilter, setRiskFilter] = useState('All');
  const [searchFilter, setSearchFilter] = useState('');

  useEffect(() => {
    async function loadData() {
      try {
        setLoading(true);
        const [patientsRes, datasetsRes] = await Promise.all([
          api.patients.getAll({ limit: 2000 }),
          api.datasets.getAll()
        ]);
        setPatients(patientsRes.patients);
        setDatasets(datasetsRes.datasets);
      } catch (err) {
        console.error('Failed to load dashboard dataset:', err);
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, []);

  // Filter options derived from actual dataset
  const uniqueDiagnoses = useMemo(() => {
    return Array.from(new Set(patients.map(p => p.diagnosis).filter(Boolean))).sort();
  }, [patients]);

  const uniqueDepartments = useMemo(() => {
    return Array.from(new Set(patients.map(p => p.department).filter(Boolean))).sort();
  }, [patients]);

  // Reactive filtering
  const filteredPatients = useMemo(() => {
    return patients.filter(p => {
      if (genderFilter !== 'All' && p.gender !== genderFilter) return false;
      if (diseaseFilter !== 'All' && p.diagnosis !== diseaseFilter) return false;
      if (departmentFilter !== 'All' && p.department !== departmentFilter) return false;
      if (riskFilter !== 'All' && p.risk_level !== riskFilter) return false;
      if (searchFilter) {
        const q = searchFilter.toLowerCase();
        return (
          p.name.toLowerCase().includes(q) ||
          p.patient_id.toLowerCase().includes(q) ||
          p.diagnosis.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [patients, genderFilter, diseaseFilter, departmentFilter, riskFilter, searchFilter]);

  const resetFilters = () => {
    setGenderFilter('All');
    setDiseaseFilter('All');
    setDepartmentFilter('All');
    setRiskFilter('All');
    setSearchFilter('');
  };

  // 8 Dashboard KPI cards calculation from filtered data
  const totalPatients = filteredPatients.length;
  const totalRecords = totalPatients;
  const avgAge = totalPatients > 0
    ? Number((filteredPatients.reduce((sum, p) => sum + p.age, 0) / totalPatients).toFixed(1))
    : 0;

  const commonDiagnosis = useMemo(() => {
    if (filteredPatients.length === 0) return 'None';
    const counts: Record<string, number> = {};
    filteredPatients.forEach(p => counts[p.diagnosis] = (counts[p.diagnosis] || 0) + 1);
    let max = 0;
    let common = 'None';
    Object.entries(counts).forEach(([diag, c]) => {
      if (c > max) {
        max = c;
        common = diag;
      }
    });
    return common;
  }, [filteredPatients]);

  const avgCost = totalPatients > 0
    ? Math.round(filteredPatients.reduce((sum, p) => sum + p.medical_expense, 0) / totalPatients)
    : 0;

  const avgStay = totalPatients > 0
    ? Number((filteredPatients.reduce((sum, p) => sum + p.length_of_stay, 0) / totalPatients).toFixed(1))
    : 0;

  const highRiskCount = filteredPatients.filter(p => p.risk_level === 'High').length;
  const datasetCount = datasets.length;

  // Chart 1 & 2: Age distribution buckets
  const ageDistributionData = useMemo(() => {
    const buckets = [
      { range: '18-29', count: 0 },
      { range: '30-44', count: 0 },
      { range: '45-59', count: 0 },
      { range: '60-74', count: 0 },
      { range: '75+', count: 0 }
    ];
    filteredPatients.forEach(p => {
      if (p.age < 30) buckets[0].count++;
      else if (p.age < 45) buckets[1].count++;
      else if (p.age < 60) buckets[2].count++;
      else if (p.age < 75) buckets[3].count++;
      else buckets[4].count++;
    });
    return buckets;
  }, [filteredPatients]);

  // Chart 3: Gender distribution
  const genderDistributionData = useMemo(() => {
    const counts = { Male: 0, Female: 0, Other: 0 };
    filteredPatients.forEach(p => {
      const g = p.gender || 'Other';
      if (counts[g] !== undefined) counts[g]++;
      else counts.Other++;
    });
    return [
      { name: 'Male', value: counts.Male, color: '#0d9488' },
      { name: 'Female', value: counts.Female, color: '#0284c7' },
      { name: 'Other', value: counts.Other, color: '#64748b' }
    ].filter(d => d.value > 0);
  }, [filteredPatients]);

  // Chart 4: Disease / diagnosis distribution
  const diseaseDistributionData = useMemo(() => {
    const map = new Map<string, number>();
    filteredPatients.forEach(p => {
      map.set(p.diagnosis, (map.get(p.diagnosis) || 0) + 1);
    });
    return Array.from(map.entries())
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 8);
  }, [filteredPatients]);

  // Chart 5: Monthly patient admissions
  const monthlyAdmissionsData = useMemo(() => {
    const map = new Map<string, { month: string; admissions: number; expense: number }>();
    filteredPatients.forEach(p => {
      if (!p.admission_date) return;
      const m = p.admission_date.substring(0, 7);
      const curr = map.get(m) || { month: m, admissions: 0, expense: 0 };
      curr.admissions++;
      curr.expense += p.medical_expense;
      map.set(m, curr);
    });
    return Array.from(map.values()).sort((a, b) => a.month.localeCompare(b.month));
  }, [filteredPatients]);

  // Chart 6: Treatment cost by disease
  const costByDiseaseData = useMemo(() => {
    const map = new Map<string, { total: number; count: number }>();
    filteredPatients.forEach(p => {
      const curr = map.get(p.diagnosis) || { total: 0, count: 0 };
      curr.total += p.medical_expense;
      curr.count++;
      map.set(p.diagnosis, curr);
    });
    return Array.from(map.entries())
      .map(([diagnosis, val]) => ({
        diagnosis,
        avg_cost: Math.round(val.total / (val.count || 1))
      }))
      .sort((a, b) => b.avg_cost - a.avg_cost)
      .slice(0, 7);
  }, [filteredPatients]);

  // Chart 7: Hospital stay analysis by department
  const stayByDepartmentData = useMemo(() => {
    const map = new Map<string, { totalStay: number; count: number }>();
    filteredPatients.forEach(p => {
      const curr = map.get(p.department) || { totalStay: 0, count: 0 };
      curr.totalStay += p.length_of_stay;
      curr.count++;
      map.set(p.department, curr);
    });
    return Array.from(map.entries())
      .map(([department, val]) => ({
        department,
        avg_stay: Number((val.totalStay / (val.count || 1)).toFixed(1))
      }))
      .sort((a, b) => b.avg_stay - a.avg_stay);
  }, [filteredPatients]);

  // Chart 8: Risk distribution
  const riskDistributionData = useMemo(() => {
    const map = { Low: 0, Moderate: 0, High: 0 };
    filteredPatients.forEach(p => {
      if (map[p.risk_level] !== undefined) map[p.risk_level]++;
    });
    return [
      { name: 'Low Risk', value: map.Low, color: '#10b981' },
      { name: 'Moderate Risk', value: map.Moderate, color: '#f59e0b' },
      { name: 'High Risk', value: map.High, color: '#ef4444' }
    ].filter(d => d.value > 0);
  }, [filteredPatients]);

  // Chart 9: Blood pressure trends (Systolic vs Diastolic across age groups)
  const bpTrendsData = useMemo(() => {
    const groups = [
      { ageGroup: '20-29', sys: 0, dia: 0, count: 0 },
      { ageGroup: '30-39', sys: 0, dia: 0, count: 0 },
      { ageGroup: '40-49', sys: 0, dia: 0, count: 0 },
      { ageGroup: '50-59', sys: 0, dia: 0, count: 0 },
      { ageGroup: '60-69', sys: 0, dia: 0, count: 0 },
      { ageGroup: '70+', sys: 0, dia: 0, count: 0 }
    ];

    filteredPatients.forEach(p => {
      let idx = 0;
      if (p.age < 30) idx = 0;
      else if (p.age < 40) idx = 1;
      else if (p.age < 50) idx = 2;
      else if (p.age < 60) idx = 3;
      else if (p.age < 70) idx = 4;
      else idx = 5;

      groups[idx].sys += p.systolic_bp;
      groups[idx].dia += p.diastolic_bp;
      groups[idx].count++;
    });

    return groups.map(g => ({
      ageGroup: g.ageGroup,
      systolic: g.count > 0 ? Math.round(g.sys / g.count) : 0,
      diastolic: g.count > 0 ? Math.round(g.dia / g.count) : 0
    }));
  }, [filteredPatients]);

  // Chart 10: Glucose vs Cholesterol health scatter sample
  const glucoseScatterData = useMemo(() => {
    return filteredPatients.slice(0, 100).map(p => ({
      x: p.glucose_level,
      y: p.cholesterol,
      bmi: p.bmi,
      diagnosis: p.diagnosis,
      risk: p.risk_level
    }));
  }, [filteredPatients]);

  if (loading) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center gap-3">
        <Loader2 className="w-8 h-8 text-teal-600 animate-spin" />
        <p className="text-xs font-medium text-slate-500">Compiling healthcare analytics telemetry...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Top Filter Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-800">
            <Filter className="w-4 h-4 text-teal-600" />
            <span>Analytical Filters</span>
            <span className="text-[11px] font-normal text-slate-500">
              Showing {filteredPatients.length} of {patients.length} records
            </span>
          </div>

          <button
            onClick={resetFilters}
            className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Filters</span>
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-5 gap-3 pt-1">
          <div>
            <label className="block text-[11px] font-semibold text-slate-600 mb-1">Gender</label>
            <select
              value={genderFilter}
              onChange={e => setGenderFilter(e.target.value)}
              className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-300 bg-white focus:outline-none focus:ring-1 focus:ring-teal-500"
            >
              <option value="All">All Genders</option>
              <option value="Male">Male</option>
              <option value="Female">Female</option>
              <option value="Other">Other</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-600 mb-1">Diagnosis</label>
            <select
              value={diseaseFilter}
              onChange={e => setDiseaseFilter(e.target.value)}
              className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-300 bg-white focus:outline-none focus:ring-1 focus:ring-teal-500"
            >
              <option value="All">All Diagnoses</option>
              {uniqueDiagnoses.map(d => (
                <option key={d} value={d}>{d}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-600 mb-1">Department</label>
            <select
              value={departmentFilter}
              onChange={e => setDepartmentFilter(e.target.value)}
              className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-300 bg-white focus:outline-none focus:ring-1 focus:ring-teal-500"
            >
              <option value="All">All Departments</option>
              {uniqueDepartments.map(d => (
                <option key={d} value={d}>{d}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-600 mb-1">Risk Stratification</label>
            <select
              value={riskFilter}
              onChange={e => setRiskFilter(e.target.value)}
              className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-300 bg-white focus:outline-none focus:ring-1 focus:ring-teal-500"
            >
              <option value="All">All Risk Levels</option>
              <option value="Low">Low Risk</option>
              <option value="Moderate">Moderate Risk</option>
              <option value="High">High Risk</option>
            </select>
          </div>

          <div className="col-span-2 sm:col-span-4 lg:col-span-1">
            <label className="block text-[11px] font-semibold text-slate-600 mb-1">Patient Search</label>
            <input
              type="text"
              placeholder="Search by name, ID..."
              value={searchFilter}
              onChange={e => setSearchFilter(e.target.value)}
              className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-300 focus:outline-none focus:ring-1 focus:ring-teal-500"
            />
          </div>
        </div>
      </div>

      {/* 8 Dashboard KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-4 gap-4">
        {/* Card 1: Total Patients */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-1">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>Total Patients</span>
            <Users className="w-4 h-4 text-teal-600" />
          </div>
          <div className="text-xl sm:text-2xl font-bold text-slate-900 tabular-nums">
            {totalPatients.toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-500">Filtered inpatient cohort</div>
        </div>

        {/* Card 2: Total Records */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-1">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>Total Records</span>
            <Database className="w-4 h-4 text-sky-600" />
          </div>
          <div className="text-xl sm:text-2xl font-bold text-slate-900 tabular-nums">
            {totalRecords.toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-500">Encounter entries</div>
        </div>

        {/* Card 3: Average Patient Age */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-1">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>Average Patient Age</span>
            <Calendar className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="text-xl sm:text-2xl font-bold text-slate-900 tabular-nums">
            {avgAge} <span className="text-xs font-normal text-slate-500">yrs</span>
          </div>
          <div className="text-[11px] text-slate-500">Cohort mean age</div>
        </div>

        {/* Card 4: Common Diagnosis */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-1">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>Common Diagnosis</span>
            <Stethoscope className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-base sm:text-lg font-bold text-slate-900 truncate" title={commonDiagnosis}>
            {commonDiagnosis}
          </div>
          <div className="text-[11px] text-slate-500">Prevalent primary disease</div>
        </div>

        {/* Card 5: Average Treatment Cost */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-1">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>Avg Treatment Cost</span>
            <span className="text-xs font-bold text-slate-400">USD</span>
          </div>
          <div className="text-xl sm:text-2xl font-bold text-slate-900 tabular-nums">
            ${avgCost.toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-500">Per patient encounter</div>
        </div>

        {/* Card 6: Average Hospital Stay */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-1">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>Average Hospital Stay</span>
            <Building2 className="w-4 h-4 text-purple-600" />
          </div>
          <div className="text-xl sm:text-2xl font-bold text-slate-900 tabular-nums">
            {avgStay} <span className="text-xs font-normal text-slate-500">days</span>
          </div>
          <div className="text-[11px] text-slate-500">Length of stay (LOS)</div>
        </div>

        {/* Card 7: High Risk Patients */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-1">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>High Risk Patients</span>
            <AlertTriangle className="w-4 h-4 text-rose-600" />
          </div>
          <div className="text-xl sm:text-2xl font-bold text-rose-600 tabular-nums">
            {highRiskCount}
            <span className="text-xs font-normal text-slate-500 ml-1.5">
              ({totalPatients > 0 ? ((highRiskCount / totalPatients) * 100).toFixed(1) : 0}%)
            </span>
          </div>
          <div className="text-[11px] text-slate-500">Requires triage priority</div>
        </div>

        {/* Card 8: Dataset Count */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-1">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>Active Datasets</span>
            <Database className="w-4 h-4 text-teal-600" />
          </div>
          <div className="text-xl sm:text-2xl font-bold text-slate-900 tabular-nums">
            {datasetCount}
          </div>
          <div className="text-[11px] text-slate-500">Mounted clinical tables</div>
        </div>
      </div>

      {/* Charts Grid: 10 Clinical Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart 1 & 2: Age Distribution Histogram */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xs font-bold text-slate-900">Patient Age Cohort Distribution</h3>
              <p className="text-[11px] text-slate-500">Patient count stratified by age brackets</p>
            </div>
            <span className="text-[10px] font-mono text-slate-400">Demographics</span>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={ageDistributionData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="range" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip
                  formatter={(value: any) => [`${value} Patients`, 'Count']}
                  contentStyle={{ fontSize: '11px', borderRadius: '8px' }}
                />
                <Bar dataKey="count" fill="#0d9488" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 3: Gender Distribution Donut */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xs font-bold text-slate-900">Gender Distribution Breakdown</h3>
              <p className="text-[11px] text-slate-500">Proportional representation of patient sex</p>
            </div>
            <span className="text-[10px] font-mono text-slate-400">Biological Sex</span>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={genderDistributionData}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={80}
                  paddingAngle={4}
                  dataKey="value"
                  label={({ name, percent }: any) => `${name} ${(percent * 100).toFixed(0)}%`}
                >
                  {genderDistributionData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ fontSize: '11px', borderRadius: '8px' }} />
                <Legend iconSize={8} wrapperStyle={{ fontSize: '11px' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 4: Disease / Diagnosis Distribution */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xs font-bold text-slate-900">Diagnosis Frequency Distribution</h3>
              <p className="text-[11px] text-slate-500">Most frequent clinical admission diagnoses</p>
            </div>
            <span className="text-[10px] font-mono text-slate-400">Pathologies</span>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={diseaseDistributionData} layout="vertical" margin={{ top: 5, right: 20, left: 40, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis type="number" tick={{ fontSize: 11 }} />
                <YAxis dataKey="name" type="category" tick={{ fontSize: 10 }} width={100} />
                <Tooltip contentStyle={{ fontSize: '11px', borderRadius: '8px' }} />
                <Bar dataKey="count" fill="#0284c7" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 5: Monthly Patient Admissions Trend */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xs font-bold text-slate-900">Monthly Inpatient Admissions</h3>
              <p className="text-[11px] text-slate-500">Chronological admission volume trend</p>
            </div>
            <span className="text-[10px] font-mono text-slate-400">Timeline</span>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={monthlyAdmissionsData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="month" tick={{ fontSize: 10 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip contentStyle={{ fontSize: '11px', borderRadius: '8px' }} />
                <Area type="monotone" dataKey="admissions" stroke="#0d9488" fill="#ccfbf1" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 6: Average Treatment Cost by Disease */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xs font-bold text-slate-900">Average Treatment Cost by Pathology</h3>
              <p className="text-[11px] text-slate-500">Mean medical expenditures per disease ($USD)</p>
            </div>
            <span className="text-[10px] font-mono text-slate-400">Financials</span>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={costByDiseaseData} margin={{ top: 10, right: 10, left: 10, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="diagnosis" tick={{ fontSize: 9 }} angle={-25} textAnchor="end" interval={0} />
                <YAxis tick={{ fontSize: 10 }} tickFormatter={v => `$${v / 1000}k`} />
                <Tooltip
                  formatter={(v: any) => [`$${v.toLocaleString()}`, 'Avg Cost']}
                  contentStyle={{ fontSize: '11px', borderRadius: '8px' }}
                />
                <Bar dataKey="avg_cost" fill="#6366f1" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 7: Hospital Stay Analysis (LOS by Department) */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xs font-bold text-slate-900">Hospital Stay (LOS) by Department</h3>
              <p className="text-[11px] text-slate-500">Mean inpatient duration in days</p>
            </div>
            <span className="text-[10px] font-mono text-slate-400">Operations</span>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stayByDepartmentData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="department" tick={{ fontSize: 10 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip
                  formatter={(v: any) => [`${v} Days`, 'Mean Stay']}
                  contentStyle={{ fontSize: '11px', borderRadius: '8px' }}
                />
                <Bar dataKey="avg_stay" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 8: Risk Stratification Distribution */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xs font-bold text-slate-900">Patient Risk Tier Stratification</h3>
              <p className="text-[11px] text-slate-500">Algorithmic categorization (Low, Moderate, High)</p>
            </div>
            <span className="text-[10px] font-mono text-slate-400">Risk ML</span>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={riskDistributionData}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  dataKey="value"
                  label={({ name, percent }: any) => `${name}: ${(percent * 100).toFixed(0)}%`}
                >
                  {riskDistributionData.map((entry, index) => (
                    <Cell key={`cell-risk-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ fontSize: '11px', borderRadius: '8px' }} />
                <Legend iconSize={8} wrapperStyle={{ fontSize: '11px' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 9: Blood Pressure Trends (Systolic vs Diastolic) */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xs font-bold text-slate-900">Hemodynamic Trends Across Age</h3>
              <p className="text-[11px] text-slate-500">Systolic vs Diastolic pressure progression (mmHg)</p>
            </div>
            <span className="text-[10px] font-mono text-slate-400">Vitals</span>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={bpTrendsData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="ageGroup" tick={{ fontSize: 10 }} />
                <YAxis tick={{ fontSize: 11 }} domain={[50, 170]} />
                <Tooltip contentStyle={{ fontSize: '11px', borderRadius: '8px' }} />
                <Legend iconSize={8} wrapperStyle={{ fontSize: '11px' }} />
                <Line type="monotone" dataKey="systolic" name="Systolic BP" stroke="#e11d48" strokeWidth={2} dot={{ r: 3 }} />
                <Line type="monotone" dataKey="diastolic" name="Diastolic BP" stroke="#2563eb" strokeWidth={2} dot={{ r: 3 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 10: Glucose vs Cholesterol Parameter Correlation */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-3 lg:col-span-2">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xs font-bold text-slate-900">Metabolic Biomarkers: Glucose vs Cholesterol Scatter</h3>
              <p className="text-[11px] text-slate-500">Cross-parameter correlation sample (Glucose mg/dL vs Cholesterol mg/dL)</p>
            </div>
            <span className="text-[10px] font-mono text-slate-400">Biomarkers</span>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <ScatterChart margin={{ top: 10, right: 20, left: 0, bottom: 10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis type="number" dataKey="x" name="Glucose" unit=" mg/dL" tick={{ fontSize: 11 }} />
                <YAxis type="number" dataKey="y" name="Cholesterol" unit=" mg/dL" tick={{ fontSize: 11 }} />
                <Tooltip
                  cursor={{ strokeDasharray: '3 3' }}
                  content={({ payload }: any) => {
                    if (payload && payload.length) {
                      const data = payload[0].payload;
                      return (
                        <div className="bg-white p-2.5 rounded-lg border border-slate-200 shadow-md text-xs space-y-1">
                          <div className="font-semibold text-slate-800">{data.diagnosis}</div>
                          <div className="text-[11px] text-slate-500">Glucose: {data.x} mg/dL</div>
                          <div className="text-[11px] text-slate-500">Cholesterol: {data.y} mg/dL</div>
                          <div className="text-[11px] text-slate-500">BMI: {data.bmi} · Risk: {data.risk}</div>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Scatter name="Patients" data={glucoseScatterData} fill="#0d9488" opacity={0.7} />
              </ScatterChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
