import {
  User,
  PatientRecord,
  DatasetMeta,
  CleaningReport,
  AnalyticsSummary,
  DiseaseDistribution,
  DemographicsSummary,
  MonthlyTrend,
  CorrelationData,
  MLModel,
  PredictionResult,
  ReportRecord
} from '../types';

const API_BASE = '/api';

function getAuthHeader(): Record<string, string> {
  const token = localStorage.getItem('healthinsight_token');
  return token ? { Authorization: `Bearer ${token}` } : {};
}

async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const headers = {
    'Content-Type': 'application/json',
    ...getAuthHeader(),
    ...options.headers
  };

  const response = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers
  });

  if (!response.ok) {
    let errorMsg = `HTTP Error ${response.status}`;
    try {
      const errorData = await response.json();
      errorMsg = errorData.message || errorMsg;
    } catch {
      // ignore
    }
    throw new Error(errorMsg);
  }

  return response.json();
}

export const api = {
  auth: {
    login: (credentials: { email: string; password: string }) =>
      request<{ user: User; token: string; message: string }>('/auth/login', {
        method: 'POST',
        body: JSON.stringify(credentials)
      }),

    register: (userData: { name: string; email: string; password: string; phone?: string; role?: string }) =>
      request<{ user: User; token: string; message: string }>('/auth/register', {
        method: 'POST',
        body: JSON.stringify(userData)
      }),

    logout: () => request<{ message: string }>('/auth/logout', { method: 'POST' }),

    getMe: () => request<{ user: User }>('/auth/me'),

    forgotPassword: (email: string) =>
      request<{ message: string; reset_link?: string; dev_token?: string }>('/auth/forgot-password', {
        method: 'POST',
        body: JSON.stringify({ email })
      }),

    resetPassword: (payload: { token: string; new_password: string }) =>
      request<{ message: string }>('/auth/reset-password', {
        method: 'POST',
        body: JSON.stringify(payload)
      })
  },

  users: {
    getProfile: () =>
      request<{ user: User; stats: { datasets_count: number; analyses_count: number; total_patients: number } }>('/users/profile'),

    updateProfile: (data: { name?: string; phone?: string; role?: string }) =>
      request<{ user: User; message: string }>('/users/profile', {
        method: 'PUT',
        body: JSON.stringify(data)
      }),

    changePassword: (passwords: { current_password: string; new_password: string }) =>
      request<{ message: string }>('/users/change-password', {
        method: 'PUT',
        body: JSON.stringify(passwords)
      })
  },

  patients: {
    getAll: (params: {
      search?: string;
      gender?: string;
      diagnosis?: string;
      department?: string;
      risk_level?: string;
      sort_by?: string;
      sort_order?: 'asc' | 'desc';
      page?: number;
      limit?: number;
    } = {}) => {
      const q = new URLSearchParams();
      if (params.search) q.append('search', params.search);
      if (params.gender) q.append('gender', params.gender);
      if (params.diagnosis) q.append('diagnosis', params.diagnosis);
      if (params.department) q.append('department', params.department);
      if (params.risk_level) q.append('risk_level', params.risk_level);
      if (params.sort_by) q.append('sort_by', params.sort_by);
      if (params.sort_order) q.append('sort_order', params.sort_order);
      if (params.page) q.append('page', String(params.page));
      if (params.limit) q.append('limit', String(params.limit));

      return request<{
        patients: PatientRecord[];
        pagination: { total: number; page: number; limit: number; total_pages: number };
      }>(`/patients?${q.toString()}`);
    },

    getById: (id: string) => request<{ patient: PatientRecord }>(`/patients/${id}`),

    create: (data: Partial<PatientRecord>) =>
      request<{ patient: PatientRecord; message: string }>('/patients', {
        method: 'POST',
        body: JSON.stringify(data)
      }),

    update: (id: string, data: Partial<PatientRecord>) =>
      request<{ patient: PatientRecord; message: string }>(`/patients/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data)
      }),

    delete: (id: string) => request<{ message: string }>(`/patients/${id}`, { method: 'DELETE' }),

    getExportUrl: () => `${API_BASE}/patients/export/csv`
  },

  datasets: {
    getAll: () => request<{ datasets: DatasetMeta[] }>('/datasets'),

    getById: (id: string) => request<{ dataset: DatasetMeta }>(`/datasets/${id}`),

    getPreview: (id: string) =>
      request<{ headers: string[]; total_rows: number; preview: Record<string, any>[] }>(`/datasets/${id}/preview`),

    upload: async (file: File, name?: string) => {
      const formData = new FormData();
      formData.append('file', file);
      if (name) formData.append('name', name);

      const response = await fetch(`${API_BASE}/datasets/upload`, {
        method: 'POST',
        headers: {
          ...getAuthHeader()
        },
        body: formData
      });

      if (!response.ok) {
        const err = await response.json();
        throw new Error(err.message || 'Dataset upload failed.');
      }

      return response.json() as Promise<{ dataset: DatasetMeta; preview: Record<string, any>[]; message: string }>;
    },

    clean: (id: string, options: any) =>
      request<{ report: CleaningReport; message: string }>(`/datasets/${id}/clean`, {
        method: 'POST',
        body: JSON.stringify({ options })
      }),

    delete: (id: string) => request<{ message: string }>(`/datasets/${id}`, { method: 'DELETE' }),

    getDownloadUrl: (id: string) => `${API_BASE}/datasets/${id}/download`
  },

  analytics: {
    getSummary: () => request<AnalyticsSummary>('/analytics/summary'),
    getDiseaseDistribution: () => request<{ distributions: DiseaseDistribution[] }>('/analytics/disease-distribution'),
    getDemographics: () => request<{ demographics: DemographicsSummary }>('/analytics/demographics'),
    getCorrelation: () => request<{ correlation: CorrelationData }>('/analytics/correlation'),
    getTrends: () => request<{ trends: MonthlyTrend[] }>('/analytics/trends'),
    getCustomChart: (payload: { x_axis: string; y_axis: string; chart_type: string }) =>
      request<{ data: any[] }>('/analytics/custom-chart', {
        method: 'POST',
        body: JSON.stringify(payload)
      })
  },

  ml: {
    train: (options: { model_type: string; target_column: string; features: string[] }) =>
      request<{ model: MLModel; message: string }>('/ml/train', {
        method: 'POST',
        body: JSON.stringify(options)
      }),

    getModels: () => request<{ models: MLModel[] }>('/ml/models'),

    predict: (vitals: {
      age: number;
      gender: string;
      bmi: number;
      systolic_bp: number;
      diastolic_bp: number;
      heart_rate: number;
      glucose_level: number;
      cholesterol: number;
      diagnosis?: string;
    }) =>
      request<{ prediction: PredictionResult }>('/ml/predict', {
        method: 'POST',
        body: JSON.stringify(vitals)
      }),

    getEvaluation: () => request<{ evaluation: MLModel }>('/ml/evaluation')
  },

  reports: {
    getAll: () => request<{ reports: ReportRecord[] }>('/reports'),
    getById: (id: string) => request<{ report: ReportRecord }>(`/reports/${id}`),
    generate: (payload: { title?: string; dataset_id?: string }) =>
      request<{ report: ReportRecord; message: string }>('/reports/generate', {
        method: 'POST',
        body: JSON.stringify(payload)
      })
  }
};
