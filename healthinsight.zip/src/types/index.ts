export interface User {
  id: string;
  name: string;
  email: string;
  phone?: string;
  role: string;
  created_at: string;
  datasets_count: number;
  analyses_count: number;
}

export interface PatientRecord {
  id: string;
  patient_id: string;
  name: string;
  age: number;
  gender: 'Male' | 'Female' | 'Other';
  height_cm: number;
  weight_kg: number;
  bmi: number;
  blood_pressure: string;
  systolic_bp: number;
  diastolic_bp: number;
  heart_rate: number;
  glucose_level: number;
  cholesterol: number;
  diagnosis: string;
  treatment: string;
  department: string;
  admission_date: string;
  discharge_date: string;
  length_of_stay: number;
  medical_expense: number;
  risk_level: 'Low' | 'Moderate' | 'High';
  readmitted: number;
}

export interface DatasetMeta {
  id: string;
  name: string;
  filename: string;
  row_count: number;
  col_count: number;
  missing_values: number;
  duplicates: number;
  numeric_cols: string[];
  categorical_cols: string[];
  columns: string[];
  upload_date: string;
  status: 'Raw' | 'Cleaned' | 'Processed';
  is_sample?: boolean;
}

export interface CleaningReport {
  before: {
    rows: number;
    columns: number;
    missing_values: number;
    duplicates: number;
  };
  after: {
    rows: number;
    columns: number;
    missing_values: number;
    duplicates: number;
  };
  outliers_handled: number;
  cleaned_file_path: string;
  cleaned_filename: string;
  preview: Record<string, any>[];
}

export interface ColumnStats {
  column: string;
  count: number;
  mean: number;
  median: number;
  min: number;
  max: number;
  std: number;
  q1: number;
  q3: number;
}

export interface AnalyticsSummary {
  kpi: {
    total_patients: number;
    total_records: number;
    average_age: number;
    common_diagnosis: string;
    average_treatment_cost: number;
    average_hospital_stay: number;
    high_risk_patients: number;
    dataset_count: number;
  };
  numeric_stats: Record<string, ColumnStats>;
}

export interface DiseaseDistribution {
  diagnosis: string;
  count: number;
  percentage: number;
  avg_cost: number;
  avg_stay: number;
  high_risk_ratio: number;
}

export interface DemographicsSummary {
  gender_breakdown: { gender: string; count: number; percentage: number }[];
  age_groups: { group: string; count: number; percentage: number; avg_bmi: number }[];
  total_count: number;
  avg_age: number;
}

export interface MonthlyTrend {
  month: string;
  admissions: number;
  avg_stay: number;
  total_expense: number;
  avg_expense: number;
}

export interface CorrelationData {
  features: string[];
  matrix: { x: string; y: string; correlation: number }[];
}

export interface MLModel {
  model_id: string;
  name: string;
  model_type: 'Logistic Regression' | 'Decision Tree' | 'Random Forest';
  target_column: string;
  features: string[];
  accuracy: number;
  precision: number;
  recall: number;
  f1_score: number;
  confusion_matrix: number[][];
  feature_importance: { feature: string; importance: number }[];
  training_size: number;
  test_size: number;
  created_at: string;
}

export interface PredictionResult {
  risk_level: 'Low' | 'Moderate' | 'High';
  risk_score: number;
  confidence: number;
  probabilities: {
    low: number;
    moderate: number;
    high: number;
  };
  contributing_factors: {
    factor: string;
    impact: 'Low' | 'Moderate' | 'High';
    explanation: string;
    weight: number;
  }[];
  clinical_recommendations: string[];
  disclaimer: string;
}

export interface ReportRecord {
  id: string;
  title: string;
  dataset_name: string;
  created_at: string;
  summary: {
    total_patients: number;
    avg_age: number;
    high_risk_patients: number;
    avg_expense: number;
    avg_stay: number;
    model_accuracy: number;
  };
  eda_findings: string[];
  model_metrics: {
    model_name: string;
    accuracy: number;
    f1_score: number;
    precision: number;
    recall: number;
  };
  recommendations: string[];
  limitations: string[];
  future_scope: string[];
}
