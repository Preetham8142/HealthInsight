import React, { useState } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { AppNavbar } from './AppNavbar';
import { AppSidebar } from './AppSidebar';
import { useAuth } from '../../context/AuthContext';
import { Menu, ChevronRight } from 'lucide-react';

export const AppLayout: React.FC = () => {
  const { isAuthenticated } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const location = useLocation();

  // If on landing page or auth pages, don't show full dashboard sidebar
  const isPublicPage = ['/', '/login', '/register', '/forgot-password', '/reset-password'].includes(location.pathname);

  // Derive breadcrumb from current path
  const pathSegments = location.pathname.split('/').filter(Boolean);
  const currentPageTitle = pathSegments.length > 0
    ? pathSegments[0].charAt(0).toUpperCase() + pathSegments[0].slice(1).replace('-', ' ')
    : 'Home';

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <AppNavbar />

      <div className="flex-1 flex">
        {/* Only show dashboard sidebar if logged in and not on public pages */}
        {isAuthenticated && !isPublicPage && (
          <AppSidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
        )}

        <main className={`flex-1 flex flex-col min-w-0 ${isAuthenticated && !isPublicPage ? 'lg:pl-64' : ''}`}>
          {/* Contextual top bar with breadcrumb on dashboard pages */}
          {isAuthenticated && !isPublicPage && (
            <div className="no-print bg-white border-b border-slate-200 px-4 sm:px-6 py-2.5 flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs text-slate-500">
                <button
                  onClick={() => setSidebarOpen(true)}
                  className="lg:hidden p-1.5 -ml-1 text-slate-600 hover:text-slate-900 rounded-md hover:bg-slate-100"
                  aria-label="Open navigation sidebar"
                >
                  <Menu className="w-4 h-4" />
                </button>
                <span>HealthInsight</span>
                <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                <span className="font-semibold text-slate-800">{currentPageTitle}</span>
              </div>

              <div className="text-xs text-slate-600 hidden sm:flex items-center gap-2">
                <span>Clinical Analytics Platform</span>
                <span className="text-slate-300">·</span>
                <span className="text-emerald-700 font-medium">PostgreSQL / SQLite Ready</span>
              </div>
            </div>
          )}

          <div className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
};
