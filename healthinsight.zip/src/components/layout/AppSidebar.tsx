import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard,
  Users,
  BarChart3,
  BrainCircuit,
  Database,
  FileText,
  GraduationCap,
  UserCheck
} from 'lucide-react';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AppSidebar: React.FC<SidebarProps> = ({ isOpen, onClose }) => {
  const menuItems = [
    { name: 'Dashboard', path: '/dashboard', icon: LayoutDashboard },
    { name: 'Patient Management', path: '/patients', icon: Users },
    { name: 'Exploratory Analytics', path: '/analytics', icon: BarChart3 },
    { name: 'Risk Prediction (ML)', path: '/risk-prediction', icon: BrainCircuit },
    { name: 'Datasets & Preprocessing', path: '/datasets', icon: Database },
    { name: 'Clinical Reports', path: '/reports', icon: FileText },
    { name: 'Internship Project', path: '/project', icon: GraduationCap },
    { name: 'User Profile', path: '/profile', icon: UserCheck }
  ];

  return (
    <>
      {/* Mobile backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 z-40 bg-slate-900/30 backdrop-blur-xs lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar container */}
      <aside
        className={`fixed top-16 bottom-0 left-0 z-40 w-64 bg-white border-r border-slate-200 flex flex-col justify-between transition-transform duration-200 ease-in-out lg:translate-x-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="p-4 space-y-6 overflow-y-auto">
          <div>
            <div className="text-[11px] font-semibold text-slate-600 uppercase tracking-wider px-3 mb-2">
              Clinical Workflows
            </div>
            <nav className="space-y-1">
              {menuItems.map(item => {
                const Icon = item.icon;
                return (
                  <NavLink
                    key={item.path}
                    to={item.path}
                    onClick={onClose}
                    className={({ isActive }) =>
                      `flex items-center gap-3 px-3 py-2 text-xs font-medium rounded-lg transition-colors ${
                        isActive
                          ? 'bg-teal-50 text-teal-700 font-semibold'
                          : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                      }`
                    }
                  >
                    <Icon className="w-4 h-4 shrink-0" />
                    <span className="truncate">{item.name}</span>
                  </NavLink>
                );
              })}
            </nav>
          </div>

          <div className="pt-4 border-t border-slate-100">
            <div className="text-[11px] font-semibold text-slate-600 uppercase tracking-wider px-3 mb-2">
              Internship Details
            </div>
            <div className="px-3 py-2.5 rounded-lg bg-slate-50 border border-slate-200/80 text-xs text-slate-600 space-y-1.5">
              <div className="font-semibold text-slate-800">Healthcare Analytics</div>
              <div className="text-[11px] text-slate-500 leading-snug">
                Python FastAPI & React Scikit-learn Risk Prediction Engine
              </div>
              <div className="text-[10px] text-teal-700 font-mono pt-1">
                6-Week Curriculum Project
              </div>
            </div>
          </div>
        </div>

        {/* Footer info in sidebar */}
        <div className="p-4 border-t border-slate-100 text-[11px] text-slate-600">
          <div className="flex items-center justify-between">
            <span>HealthInsight v1.0</span>
            <span className="text-emerald-700 font-medium">Online</span>
          </div>
        </div>
      </aside>
    </>
  );
};
