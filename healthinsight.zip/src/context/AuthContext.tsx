import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '../types';
import { api } from '../services/api';

interface AuthContextType {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string, rememberMe?: boolean) => Promise<void>;
  register: (userData: { name: string; email: string; password: string; phone?: string; role?: string }) => Promise<void>;
  logout: () => void;
  updateUser: (data: Partial<User>) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(() => {
    try {
      const stored = localStorage.getItem('healthinsight_user');
      return stored ? JSON.parse(stored) : null;
    } catch {
      return null;
    }
  });

  const [token, setToken] = useState<string | null>(() => {
    return localStorage.getItem('healthinsight_token') || null;
  });

  const [isLoading, setIsLoading] = useState<boolean>(true);

  useEffect(() => {
    async function verifyAuth() {
      const savedToken = localStorage.getItem('healthinsight_token');
      if (!savedToken) {
        setIsLoading(false);
        return;
      }

      try {
        const res = await api.auth.getMe();
        setUser(res.user);
        localStorage.setItem('healthinsight_user', JSON.stringify(res.user));
      } catch (err) {
        console.warn('Session verification failed, resetting auth state:', err);
        localStorage.removeItem('healthinsight_token');
        localStorage.removeItem('healthinsight_user');
        setUser(null);
        setToken(null);
      } finally {
        setIsLoading(false);
      }
    }

    verifyAuth();
  }, []);

  const login = async (email: string, password: string, rememberMe = true) => {
    const res = await api.auth.login({ email, password });
    setUser(res.user);
    setToken(res.token);

    if (rememberMe) {
      localStorage.setItem('healthinsight_token', res.token);
      localStorage.setItem('healthinsight_user', JSON.stringify(res.user));
    } else {
      sessionStorage.setItem('healthinsight_token', res.token);
      sessionStorage.setItem('healthinsight_user', JSON.stringify(res.user));
      localStorage.setItem('healthinsight_token', res.token);
      localStorage.setItem('healthinsight_user', JSON.stringify(res.user));
    }
  };

  const register = async (userData: { name: string; email: string; password: string; phone?: string; role?: string }) => {
    const res = await api.auth.register(userData);
    setUser(res.user);
    setToken(res.token);
    localStorage.setItem('healthinsight_token', res.token);
    localStorage.setItem('healthinsight_user', JSON.stringify(res.user));
  };

  const logout = () => {
    api.auth.logout().catch(() => {});
    localStorage.removeItem('healthinsight_token');
    localStorage.removeItem('healthinsight_user');
    sessionStorage.removeItem('healthinsight_token');
    sessionStorage.removeItem('healthinsight_user');
    setUser(null);
    setToken(null);
  };

  const updateUser = (data: Partial<User>) => {
    if (user) {
      const updated = { ...user, ...data };
      setUser(updated);
      localStorage.setItem('healthinsight_user', JSON.stringify(updated));
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isAuthenticated: !!user && !!token,
        isLoading,
        login,
        register,
        logout,
        updateUser
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
