"""
HealthInsight - Healthcare Data Analytics & Patient Risk Prediction Platform
FastAPI Backend Application Entry Point
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import os

app = FastAPI(
    title="HealthInsight API",
    description="Healthcare Data Analytics & Patient Risk Prediction Platform",
    version="1.0.0"
)

# CORS Configuration
origins = [
    "http://localhost:3000",
    "http://127.0.0.1:3000",
    os.getenv("FRONTEND_URL", "*")
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def root():
    return {
        "status": "online",
        "service": "HealthInsight Analytics & Risk Prediction Engine",
        "version": "1.0.0",
        "documentation": "/docs"
    }

@app.get("/api/health")
def health_check():
    return {"status": "healthy", "database": "connected"}

# Note: In local Python environment, include routes:
# from app.routes import auth, patients, datasets, analytics, ml, reports
# app.include_router(auth.router, prefix="/api/auth", tags=["Authentication"])
# app.include_router(patients.router, prefix="/api/patients", tags=["Patients"])
# app.include_router(datasets.router, prefix="/api/datasets", tags=["Datasets"])
# app.include_router(analytics.router, prefix="/api/analytics", tags=["Analytics"])
# app.include_router(ml.router, prefix="/api/ml", tags=["Machine Learning"])
# app.include_router(reports.router, prefix="/api/reports", tags=["Reports"])

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
